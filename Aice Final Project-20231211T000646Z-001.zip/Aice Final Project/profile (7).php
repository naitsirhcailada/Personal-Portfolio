<?php
session_start();

?>
<?php 
 if(!isset($_SESSION['user_ID'])){
  header("location:logout.php");
 }
?>



<!doctype html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   
    <link rel="stylesheet" href="css/profile.css" type="text/css" media="screen" />
</head>
<title>Aice Nasugbu Branch - Profile</title>
<body>
<!--Navbar-->

<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="aice.php">Aice</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" class ="navbar-txt"href="aice.php">Home <span class="sr-only">(current)</span></a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link " href="map.php"  >Map</a>
      </li>

     
      <form class="form-inline my-2 my-lg-0" method = "POST" action = "aice.php">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name ="search">
      <button class="btn btn-primary my-2 my-sm-0" type="submit" >Search</button>
    </form>
    <?php 
      include 'dbconn.php';
			$query = "select *from aice_product";
		  $result = mysqli_query($link,$query);
          $row = mysqli_fetch_assoc($result)
  ?>
     <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
<li class="nav-item">
  <a class="nav-link" href = "cart.php"><i class="fas fa-shopping-cart" ><span class="badge"><?php echo ($row);?></span></i></a>
</li>

<li class="nav-item">
  <a class="nav-link"  data-toggle="modal" data-target="#modalContactForm"><i class="fas fa-bell"></i><span class="badge">5</span></a>
</li>



    <li class="nav-item dropdown" id="dropdown" name = "fullname">
      <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];
                             $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                        ?>
	 
 
  <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2" >'; ?> <?php echo $_SESSION["Name"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="profile.php"><i class ="fa fa-user"></i>&nbsp; Profile</a>
          <a class="dropdown-item" href="cart.php"><i class = "fa fa-shopping-cart"></i>&nbsp;Cart</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"onclick="return  confirm('Are you sure you want to log out')"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
        </div>
      </li>
   
   
    </ul>

  </div> <!--Collapase navbar-->
</nav>

<body>
<div class="container">
  
    <div class="row profile">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<!-- SIDEBAR USERPIC -->
				<div class="profile-userpic">
                <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user">'; ?>
				</div>
				<!-- END SIDEBAR USERPIC -->
				<!-- SIDEBAR USER TITLE -->
				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
					<?php echo $_SESSION['Name'];?>
					</div>
                    <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];

                            
                            $query = "SELECT *FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                            ?>

					<div class="profile-usertitle-job">
					<?php echo $row['Type'];?>
          <?php
          
          $total = 0; 
        
          include 'dbconn.php';
          $query = "select *from aice_order where Name = '".$_SESSION['Name']."' ";
          $result = mysqli_query($link,$query);
while($data = mysqli_fetch_assoc($result))
{   
    $quantity = $data['quantity'];
    $price = $data['price'];
    $total = $total + ($data["quantity"] * $data["price"]);  

   
   
}


        ?>
                            	<p> Total of sold items: &nbsp;₱<?php echo $total; ?></p>
					</div>
				</div>
				<!-- END SIDEBAR USER TITLE -->
				<!-- SIDEBAR BUTTONS -->
				<div class="profile-userbuttons">
					<button type="button" class="btn btn-success btn-sm">Update Profile</button>
				
				</div>
				<!-- END SIDEBAR BUTTONS -->
				<!-- SIDEBAR MENU -->
   
                     <div class="col-sm-6">
                         <div class="col-xs-3">
					<!-- Nav tabs -->
                    <ul class="nav nav-tabs tabs-left">
                    <li><a href="#home" data-toggle="tab"><i class="fas fa-user"></i>About Me</a>

                    </li>
                    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from aice_msg  where Name = '".$_SESSION['Name']."' && msg_status = 'unread'";
		  $result = mysqli_query($link,$query);
          $notif = mysqli_num_rows($result);
          $rows = mysqli_fetch_assoc($result)
          ?>
      
   
                    <li><a href="#settings" data-toggle="tab" ><i class="fas fa-comment-alt"></i>Chat<span class = "badge"><?php echo ($notif);?></span></a>
                    
                    </li>
    
                    <?php 
                  error_reporting(E_ALL ^ E_WARNING); 
                include 'dbconn.php';
                $query = "select *from aice_order  where Name = '".$_SESSION['Name']."' AND Status != 'Received'";
                $result = mysqli_query($link,$query);
                    $data = mysqli_num_rows($result);
 ?>
                    <li><a href="#profile" data-toggle="tab"><i class="fas fa-shopping-bag"></i>My Purchase<span class = "badge"><?php echo ($data);?></span></a>

                    </li>
                    <?php 
                  error_reporting(E_ALL ^ E_WARNING); 
                include 'dbconn.php';
                $query = "select *from aice_order  where Name = '".$_SESSION['Name']."' AND Status = 'Received'";
                $result = mysqli_query($link,$query);
                    $data = mysqli_num_rows($result);
 ?>
                    <li><a href="#messages" data-toggle="tab"><i class="fas fa-clock"></i>View Recent Purchases<span class = "badge"><?php echo ($data);?></span></a>

                    </li>
                   
                </ul>
			
</div>
</div>
				<!-- END MENU -->
			</div>
		</div>
       
  
		<div class="col-md-9">
            <div class="tab-content">
            <div class="tab-pane active" id="home">
         
          
  <div class="card">
      <div class = "card-header"> <h5 class="card-title">About Me</h5> </div>
      <div class="card-body">
       
     
       <div class="form-floating">
         <label class ="form-label" for ="username"> Username</label>
         <input type = "text" class = "form-control" name="username" id = "username" value = "<?php echo $row["username"];?>" style="cursor:pointer;" readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="Name"> Name</label>
         <input type = "text" class = "form-control" name = "Name" id = "Name" value = "<?php echo $row["Name"]; ?>" style="cursor:pointer;"readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="Contact_number"> Contact Number</label>
         <input type = "number" class = "form-control" name = "Contact_number"id = "Contact_number" value = "<?php echo $row["Contact_number"]; ?>" style="cursor:pointer;"readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="user_email"> Email</label>
         <input type = "email" class = "form-control" name = "user_email"id = "user_email" value = "<?php echo $row["user_email"]; ?>" style="cursor:pointer;"readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="Address"> Current Address</label>
         
         <input type = "text" class = "form-control"name = "Address" id = "Address" value = "<?php echo $row["Address"]; ?>" style="cursor:pointer;"readonly/></p>
       
        </div>
      <div class="form-floating">
         <label class ="form-label" for ="birthdate"> Birth Date</label>
         <input type = "date" class = "form-control" name = "birthdate"id = "birthdate" value = "<?php echo $row["birthdate"]; ?>" style="cursor:pointer;" readonly/></p>
      </div>

      </div>
      <div class = "card-footer">
      <input type = "hidden" name = "user_ID" value = "<?php echo $row['user_ID'];?>"/>
      <input type="button" name = "updateprofile" class="btn btn-success btn-sm" value = "Edit">
      
    </div>

      </div>
     

    </div>

    
            <div class="tab-pane " id="profile">
         
    <div class="card">
    <div class="title">Purchase Reciept 
    
    <a href = "export.php" target="_blank"> <button type ="button" class = "btn btn-warning"><i class="fas fa-receipt"></i>Print Reciept</button></a>
    <p class = "note">Note: Don't forget to click the order received once you receive the order</p>
    </div>
   
    <div class="info">
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_order where Name = '".$_SESSION['Name']."' AND Status != 'Received' ";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
        <div class="row">
            <div class="col-7"> <span id="heading">Date</span><br> <span id="details"><strong><?php echo $row['order_time'];?></strong></span> </div>
            <div class="col-5 pull-right"> <span id="heading">Order No.</span><br> <span id="details"><strong><?php echo $row['order_id']; ?></strong></span> </div>
            <div class="col-9"> <span id="name"><strong><?php echo $row['product_name'];?> </strong></span> </div>
            <div class="col-3"> <span id="price"><strong>₱<?php echo $row['total'];?></span> <p class = "status">&nbsp;<?php echo $row['Status'];?></strong> </p></div>
            <div class="col-9"> <span id="name">Shipping</span> </div>
            <div class="col-3"> <span id="price">Free</span> </div>
            <div class="col-3"><p class = "total">Total Price ₱<big><?php echo $row['total'];?></big></p></div>

            <form method = "POST" action = "update-order-status.php">
              <input type = "hidden" value="<?php echo $row['order_id'];?>" name = "order" />
           
            <div class="col-2"><button type ="submit" id = "submit"class = "btn btn-success"<?php if ($row['Status'] !== 'To Deliver'){ ?> disabled <?php   } ?>name = "update">Order Received</button>&nbsp;
            
          
          </div>
          </form>
    </div>
   
        <?php } ?>
        
    </div>
   
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_login where Name = '".$_SESSION['Name']."' ";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
    <div class="tracking">
        <div class="title">Billing Address:<?php echo $row['Address'];?></div>
        
    </div>
<?php } ?>
    <div class="footer">
        <div class="row">
          
          
        </div>
           
        </div>
    </div>
</div>



            <div class="tab-pane " id="messages">
            <?php 
             include 'dbconn.php';
            
			 $query = mysqli_query($link,"SELECT * FROM  aice_order WHERE Status = 'Received' AND  Name = '".$_SESSION['Name']."' ");
			
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
         
<div class = "card" id="history-card">
  <div class = "card-header">Recent Purchase &nbsp;<span><a href="delete-order-history.php?order_id=<?php echo $row['order_id']; ?>" class = "btn btn-danger">Delete</a><p class = "note">Note: Once you delete the history of purchase it will be deleted from our database</p></span></div>
  <div class = "card-body">
          Order No:<strong><?php echo $row['order_id'];?> </strong><br>
          Product:&nbsp;<strong><?php echo $row['product_name'];?></strong><br>
          Quantity:&nbsp;<strong><?php echo $row['quantity'];?></strong><br>
        
          Total:&nbsp;<strong>₱<?php echo $row['total'];?></strong><br>
          Date Ordered: &nbsp;<strong><?php echo $row['order_time'];?></strong><br>
          Courier: &nbsp;<strong><?php echo $row['courier'];?></strong>
       </div>
       </div>

<?php } ?>

            </div>
            
            <div class="tab-pane " id="settings">
       
        
         
              <form method = "POST"action = "insert-message.php">
          <div class = "card" id=  "message">
          
       <div class = "card-header">CHAT</div>
       <div class = "card-body">
       <?php 
                                    include 'dbconn.php';
                                    $qry = "select *from aice_login WHERE Name != '".$_SESSION['Name']."'  ";
                                    $results = mysqli_query($link,$qry);
                                    ?>
                                    
                            <select class = "form-control" id ="select-user" name="select-user" style="height:40px;"required>
                               
                                    <option disabled selected value = "">Send To</option>
                                        <?php
                                        while ($data = $results->fetch_assoc())
                                        {
                                            $Name = $data['Name'];
                                            echo "<option value ='$Name'> $Name</option>";
                                        
                                        }
                                        
                                        ?>
	                                  </select>
      

     <div class = "msg-form">
   
     <?php 
        include 'dbconn.php';
        
			 $query = mysqli_query($link,"SELECT * FROM  aice_msg WHERE Name = '".$_SESSION['Name']."' || receiver = '".$_SESSION['Name']."'");
			
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
        
       
            <h5> <strong><?php echo $row['Name'];?></strong> </h5>
          
       <h6 class="time-delivered"> &nbsp;<strong>(<?php echo $row['type'];?>) </strong>&nbsp;Delivered:<?php echo $row['msg_time'];?></h6><br>
      <p><?php echo $row['subject'];?></p>
       <?php 
       $message = $row['message'];
       if($row['Name'] == $_SESSION['Name']){
          echo '<input style="background-color:#2A6AE1; border:none; color:white; border-radius:15px; cursor:pointer;"  value = "'.$message.'" class="form-control" readonly>';
       }else{
        echo '<input style="background-color:gray; border:none; color:black;border-radius:15px; cursor:pointer;"  value = "'.$message.'" class="form-control" readonly>';
       }
       ?>
     
        <input type = "hidden"  name = "msg_id" value ="<?php echo $row['msg_id'];?>"/>
        <input type = "hidden" name = "react" values = "" />
      
      <button type = "submit" name = "heart"class = "btn btn-outline-primary" ><i class="fas fa-thumbs-up"></i><span class ="badge"><?php echo $row['react'];?></span></button>

     
      <a href= "delete-msg.php?msg_id=<?php echo $row['msg_id']; ?>">Delete</a>
     
       <?php } ?>
        </div>
       </div>
      
       <div class = "card-footer">
         <input type="hidden" value ="<?php echo $_SESSION['Name'];?>" name ="Name"/>
         <input type="hidden" value ="<?php echo $_SESSION['Type'];?>" name ="Type"/>
      
         <input type = "hidden" name = "stat" value = "unread" />
         <input type = "text" class ="form-control" name = "subject" placeholder="Subject" style = "margin-bottom:0.5rem;"/>
       <textarea placeholder=  "Aa" class = "form-control"  rows = "6" cols = "60" name="message"></textarea><br>
         <button type = "submit" name = "send" class = "btn btn-primary"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
         <button type = "button" name = "reply" class = "btn btn-primary">Reply</button>
       </div>
       </div>
     

            </div>
       </form>
     


            </div>
		</div>
       
	</div>
</div>




    </body>
        </html>
        <script>
            $('.nav-tabs > li > a').hover(function () {
    $(this).tab('show');
});
            </script>
    