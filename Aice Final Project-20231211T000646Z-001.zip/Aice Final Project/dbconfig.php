<?php 
// Database configuration 
$servername="localhost:3307";
$username="root";
$password="root";
$dbname="aice";
 
// Create database connection 
$db = new mysqli($servername, $username, $password, $dbname); 
 
// Check connection 
if ($db->connect_error) { 
    die("Connection failed: " . $db->connect_error); 
}