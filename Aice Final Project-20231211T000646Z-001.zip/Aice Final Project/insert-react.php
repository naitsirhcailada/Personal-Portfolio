<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3307", "root", "root", "aice");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
if(isset($_POST['react'])){

   
$msg_id = $_POST['msg_id'];
// Escape user inputs for security
$react = mysqli_real_escape_string($link, $_POST['react']);



$sql = " UPDATE aice_msg SET react = react+1 WHERE msg_id='".$msg_id."' ";


}
if(mysqli_query($link, $sql)){
    echo '<script>alert("react successful")</script>';  
 
     header("Location:profile.php");
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>