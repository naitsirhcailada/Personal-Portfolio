<?php 
 session_start();

 
 
 if(count($_POST)>0) {
   $password = $_POST['password'];
  $encrypt = md5($password);
     $con = mysqli_connect('127.0.0.1:3307','root','root','aice') or die('Unable To connect');
     $result = mysqli_query($con,"SELECT * FROM aice_login WHERE user_email='" . $_POST["username"] . "' and password = '". $encrypt."'");
     $row  = mysqli_fetch_array($result);
     if(is_array($row)) {
     $_SESSION["user_ID"] = $row['user_ID'];
     $_SESSION["Name"] = $row['Name'];
     $_SESSION['Type'] = $row['Type'];
     
    
     }

 
    
     else {
      echo '<script>alert("Invalid username and password")</script>';
     }
 }

 if(isset($_SESSION["user_ID"]) && ($_SESSION["Type"] =="user")  ) {
  echo "<script type='text/javascript'>alert('You have successfully login');</script>";
 header("Location:aice.php");
 }
 else if(isset($_SESSION["user_ID"]) && ($_SESSION["Type"] =="admin")  ) {
  echo '<script>alert("You have successfully login")</script>';
  header("location:admin/admin-html/admin.php");
  } 
  else if(isset($_SESSION["user_ID"]) && ($_SESSION["Type"] =="courier")  ) {
    echo '<script>alert("You have successfully login")</script>';
    header("location:courier.php");
    }
 



 
?>
<!doctype html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="css/index.css" type="text/css" media="screen"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<title>Aice Login</title>
</head>

    <body>
   
<section class="vh-100">
    <div class="container-fluid h-custom">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-md-9 col-lg-6 col-xl-5">
          <img src="images/aice-logo.jpg" class="img-fluid"
            alt="Sample image">
        </div>
        <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
        <h3>LOGIN <p style="font-family: 'Lobster', cursive; color: blueviolet;" >Aice Ice Cream</p></h3>
          <form method = "POST" action=  "index.php">
            <!-- Email input -->
            <div class="form-floating mb-4">
              <input type="text" id="form3Example3" class="form-control form-control-lg"
                placeholder="Enter username" name = "username" required/>
              <label class="form-label" for="form3Example3">Email</label>
            </div>
  
            <!-- Password input -->
            <div class="form-floating mb-3">
              <input type="password" id="form3Example4" class="form-control form-control-lg"
                placeholder="Enter password"name="password" required />
              <label class="form-label" for="form3Example4">Password</label>
            </div>
  
            <div class="d-flex justify-content-between align-items-center">
              <!-- Checkbox -->
              <div class="form-check mb-0">
                <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3" />
                <label class="form-check-label" for="form2Example3">
                  Remember me
                </label>
              </div>
              <a href="#!" class="text-body">Forgot password?</a>
            </div>
  
            <div class="text-center text-lg-start mt-4 pt-2">
              <button type="submit" class="btn btn-primary btn-lg"
                style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
              
            </div>
  
          </form>
        </div>
      </div>
    </div>
    <footer class="footer-distributed" id="footer">

<div class="footer-right">

  <a href="#"><i class="fab fa-facebook"></i></a>
  <a href="#"><i class="fab fa-twitter"></i></a>
  

</div>

<div class="footer-left">

  <p class="footer-links">
    <a class="link-1" href="aice.php">Home</a>

    <a href="menu.php">Menu</a>

    <a href="map.php">Map</a>

    <a href="contactus.html">Contact Us</a>

    <a href="#">About</a>
  </p>

  <p>Aice Ice Cream &copy; 2021</p>
</div>

</footer>
  </section>
</body>
  </html>
