<?php 

session_start();



    $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['update']) )
	{
		
		$order_id = $_POST['order'];
        $Status = $_POST['update'];
		$date_delivered = date ('Y-m-d H:i:s', strtotime("+7 hour"));
        
		
		$query = " UPDATE aice_order SET Status = 'Received', date_delivered = '".$date_delivered."' WHERE order_id='".$order_id."'";

		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:profile.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}
	
?>
