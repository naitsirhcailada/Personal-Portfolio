<?php 

session_start();



    $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['updatenotif']) )
	{
		
		$order_id = $_POST['order_id'];
       
		$notif =   $_POST['clearnotif'];
		
		$query = " update aice_order set`notif` = '$notif'";

		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:aice.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}
	
?>
