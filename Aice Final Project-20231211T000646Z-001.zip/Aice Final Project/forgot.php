<?php 
include 'dbconn.php';
error_reporting(0);
					error_reporting(0);$Email = $_POST['user_email'];
					$Subject = "Password Request";
					$Letter="Unknown Body";
					
						if(ISSET($_POST['confirmrequest'])){
							$user_ID = $_POST['ofcnum'];
							$query = " UPDATE aice_login SET request_status = 'completed' WHERE user_ID = '".$user_ID."' ";

							$query_run = mysqli_query($link,$query);
		
							
							$password = $_POST['pss'];
							
							if ($password != '') {
							
								$user_ID = $_POST['ofcnum'];
								$Name = $_POST['Name'];
							
								$user_email = $_POST['user_email'];
								$Address = $_POST['Address'];
								$Type = $_POST['Type'];

								$Subject = "Password Request";
								
								
								
								$Letter = "Good Day. Your Password Request has been processed . Password Request Number $user_ID .  Name: $Name  Account Type: $Type Email: $user_email with the Address of $Address . Your Password is
								: .$password. . Please do not share this email with others. Thank You. from Aice";
								
									echo '<script>alert ("Done")</script>';
							
						
							}
							
							
								
							
								
							
							
						}
					
					?>
					
					
					
				<html>
                    <<head>
                    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
                    </head>
                    <body>	
		<div class="container">			
		</br></br>
		
		<?php 
								if(isset($_POST['try'])){

										$Name = $_POST['Name'];
										
										$user_email = $_POST['user_email'];
												
											$query = mysqli_query ($link, "SELECT * FROM `aice_login` WHERE Name='".$Name."'  AND user_email='".$user_email."'") or die(mysqli_error());
											
								} else {
									
									$query = mysqli_query ($link, "SELECT * FROM `aice_login` WHERE Name=''  AND user_email=''") or die(mysqli_error());
											
									
								}
								
								
											
										while($fetch = mysqli_fetch_array($query)){	
											
											?>
									<form action="" method="POST">
									<div class="card">
									
									<div class="row col-md-6">
									<label>Official Number <?php echo $fetch['user_ID']?></label>
									<input type="hidden" name="ofcnum" value="<?php echo $fetch['user_ID']?>" class="form-control" required="required"/>
											
									</br>
									<label>Account Name <?php echo $fetch['Name']?></label>
									<input type="hidden" name="name" value="<?php echo $fetch['Name']?>" class="form-control" required="required"/>
									
											
									</br>
									<label>Email <?php echo $fetch['user_email']?></label>
									<input type="hidden" name="user_email" value="<?php echo $fetch['user_email']?>" class="form-control" required="required"/>

									</br>
									</div>
									
									
									
									<div class="row col-md-6">
									
									<label>User Type <?php echo $fetch['Type']?></label>
									<input type="hidden" name="usrtyp" value="<?php echo $fetch['Type']?>" class="form-control" required="required"/>
													
									</br>
									<label>Address <?php echo $fetch['Address']?></label>
									<input type="hidden" name="address" value="<?php echo $fetch['Address']?>" class="form-control" required="required"/>
											
									</br>
									<label>Encrypted Password <?php echo $fetch['password']?></label>
									<input type="text" name="pss" value="<?php echo $fetch['password']?>" class="form-control" required="required"/>
											
									</br>
									</div>
									<center>
									<input type="text" name="pss" value="" class="form-control" required="required"/>
									
									<button class="btn" id="" type="submit" name="confirmrequest"><i class='bx bx-list-check'></i> Confirm </button>
									</br>
									<label><a href="https://md5decrypt.net/en/" style=" font-size: 15px;" target="_blank">proceed to md5decrypt.net</a></label>
									</br>
												
									
									</center>
									
									</div>
									</form>	
											<?php }?>
		
		<a href="https://mail.google.com/mail/?view=cm&fs=1&to=<?php echo $Email ?>&su=<?php echo $Subject ?>&body=<?php echo $Letter ?>" target="_blank"><h4>Send Email</h4></a>
									
		
	</div>	
	<div class="container"  style="overflow-x:auto;">	
   <form method = "POST"action="">
<input type="text" name="search" class="form-control">
<button type="submit" name = "submit" class="btn btn-success">Find</button>
    </form>
	<table id = "table" class="table table-bordered" style="margin-left: 50%px; overflow-x:auto; overflow-y:auto;">
			
				<tr>
					<th>ID Number</th>
					<th>Account Name</th>
			
					<th>User type</th>
					<th>Address</th>
					
					
					<th>Action</th>
				</tr>
	
	
		<?php

     

		$query = mysqli_query($link, "SELECT * FROM `aice_login` WHERE request_status='request' ") or die(mysqli_error());
					
		
				if(isset($_POST['submit']))
				{
				
					$valueToSearch = $_POST['search'];
					$query = mysqli_query ($link, "SELECT * FROM `aice_login` WHERE CONCAT(`user_ID`, `Name`, `user_email`,`Address`,`Type`) LIKE '%".$valueToSearch."%'") or die(mysqli_error());
					echo '<script>alert (" Loading ")</script>';
				} else if(isset($_POST['remove'])) {
					$query = mysqli_query($link, "SELECT * FROM `aice_login`") or die(mysqli_error());
					echo '<script>alert (" Loading ")</script>';
				}
					
				while($fetch = mysqli_fetch_array($query)){
					?>
					
					
					<tr>       
						<td><?php echo $fetch['user_ID']?></td>
						<td><?php echo $fetch['Name']?> 
						<td><?php echo $fetch['Type']?></td>
						<td><?php echo $fetch['Address']?></td>
						<td ><?php if($fetch['request_status'] =='request'){ echo ''.$fetch['user_email'].'&nbsp;is requesting';}else{echo 'no request';}?></td>
						<td><button class="btn" id="" type="button"  data-toggle="modal" data-target="#accountmodal<?php echo $fetch['user_ID']?>"><i class='bx bx-list-check'></i> View </button></td>
						
						

					</tr>
				
			
					<div class="modal fade" id="accountmodal<?php echo $fetch['user_ID']?>" aria-hidden="true">
						<div class="modal-dialog modal-dialog-centered">
							<div class="modal-content">
								<form method="POST" action="">	
									<div class="modal-header">
										<h4 class="modal-title">View Password Requests</h4>
									</div>
									<div class="row modal-body">
										<div class="col-md-3"></div>
										<div class="col-md-6">
											<div class="col-md-6form-group">
												<label>Request Number <?php echo $fetch['user_ID']?></label>
												<label>Account Name <?php echo $fetch['Name']?> </label>
												<label>Email <?php echo $fetch['user_email']?></label>
												<label>Address <?php echo $fetch['Address']?></label>
												<label>User Type <?php echo $fetch['Type']?></label>
												
												</div>
											<div class="col-md-6form-group">
												<input type="hidden" name="Name" value="<?php echo $fetch['Name']?>" class="form-control" required="required"/>
												
												<input type="hidden" name="user_email" value="<?php echo $fetch['user_email']?>" class="form-control" required="required"/>

											</div>
											
											<button class="btn" id="" type="submit" name="try"><i class='bx bx-list-check'></i> Confirm Account </button></td>
											
											</form>
										</div>
									</div>

									<div style="clear:both;"></div>
									<div class="modal-footer">
									<center>
									<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
									</center>
									</div>
								
							</div>
						</div>
					</div>

			<?php } ?>
	</table>
                </body>
                </html>
	
	
		
					