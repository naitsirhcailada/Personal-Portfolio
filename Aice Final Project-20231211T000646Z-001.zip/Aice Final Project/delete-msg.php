<?php
session_start();
include "dbconn.php"; // Using database connection file here

$msg_id = $_GET['msg_id']; // get id through query string
$Name = $_SESSION['Name'];
$del = mysqli_query($link,"delete from aice_msg where  msg_id = '$msg_id' && Name ='".$Name."' "); // delete query

if($del)
{
    mysqli_close($link); // Close connection
    header("location:profile.php"); // redirects to all records page
    exit;	
}
else
{
    echo '<script>alert("You can only delete your message")</script>'; // display error message if not delete
}
?>