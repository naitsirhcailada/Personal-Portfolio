<?php
session_start();
?>
<?php 
 if(!isset($_SESSION['user_ID'])){
  header("location:logout.php");
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name = "viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link rel="stylesheet" href="css/cart.css" type="text/css" media = "screen"  />
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Hind+Madurai:wght@600&family=Overpass:wght@300&display=swap" rel="stylesheet">
</head>
<title>Cart List - Aice Nasugbu Branch</title>
<style>
 

</style>
<body>
  <!--Navbar-->
<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="aice.php">Aice</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="aice.php">Home <span class="sr-only">(current)</span></a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link " href="map.php">Map</a>
      </li>

     
      <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-primary my-2 my-sm-0" type="submit">Search</button>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."' && cart_status != 'Ordered'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
    <li class="nav-item">
<a class="nav-link" href="cart.php" ><i class="fas fa-shopping-cart" ><span class="badge"><?php echo ($row);?></span></i></a>
</li>
<?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);
      include 'dbconn.php';
			$query = "select *from aice_order  where Name = '".$_SESSION['Name']."' && notif ='unread'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
          $rows= mysqli_fetch_assoc($result);
 ?>
<li class="nav-item">
<div class="dropdown" id=  "ordernotif">

  <button class="btn btn-outline-secondary dropdown-toggle" type="button" name= "submit" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-bell"><span class = "badge"><?php echo ($row);?></span></i>
  </button>
  
  <form action = "updatenotif.php" method = "POST">
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">


   
      <input type ="hidden" name = "order_id" value = "<?php echo $rows['order_id'];?>"/>
      <input type ="hidden" name = "clearnotif" value = "read"/>
      <h6 class="dropdown-header">
    <button type = "submit" name = "updatenotif" class = "notif" <?php if ($rows['notif'] !== 'unread'){  ?> disabled <?php   } ?>>Clear Notifications<br><?php if($rows['notif'] !== 'unread'){ echo'No New Notifications';}?></button></h6>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);

      include 'dbconn.php';
      
			$query = "select *from aice_order  where Name = '".$_SESSION['Name']."' && notif ='unread'";
		  $result = mysqli_query($link,$query);
        
          while($rows= mysqli_fetch_assoc($result)){


 ?>   
           
           <p class = "dropdown-body"><small>Order No:<strong><?php echo $rows["order_id"]; ?></strong>&nbsp;is &nbsp;<strong><?php echo $rows["Status"]; ?></strong></small></p>
         
      

    
  
         <?php } ?>
         <h6 class = "dropdown-footer">
         <a href = "profile.php" class = "btn btn-text-white" style ="color:blue;">See All Notifications</a></h6>
  </div>
 

</div>

</li>
<?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);
      include 'dbconn.php';
			$query = "select *from aice_msg  where receiver = '".$_SESSION['user_email']."' && msg_status ='unread'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
          $rows= mysqli_fetch_assoc($result);
 ?>
<li class="nav-item">
<div class="dropdown" id = "msgnotif" >

  <button class="btn btn-outline-secondary dropdown-toggle" type="button" name= "submit" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-comment-alt"><span class = "badge"><?php echo ($row);?></span></i>
  </button>
  
  <form action = "updatemsg.php" method = "POST">
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">


   
      <input type ="hidden" name = "msg_id" value = "<?php echo $rows['msg_id'];?>"/>
      <input type ="hidden" name = "clearnotif" value = "read"/>
      <h6 class="dropdown-header">
    <button type = "submit" name = "updatenotif" class = "notif" <?php if ($rows['msg_status'] !== 'unread'){  ?> disabled <?php   } ?>>Clear Notifications<br><?php if($rows['msg_status'] == 'read'){ echo'No New Notifications';}?></button></h6>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);

      include 'dbconn.php';
      
			$query = "select *from aice_msg WHERE receiver = '".$_SESSION['user_email']."' && msg_status ='unread'";
		  $result = mysqli_query($link,$query);
        
          while($rows= mysqli_fetch_assoc($result)){


 ?>   
           
           <p class = "dropdown-body"><strong><?php echo $rows["Name"]; ?></strong><span class = "time">-Sent a message-<br><?php echo $rows['msg_time'];?></span><br>
           </p><br>
         
      

            
  
         <?php } ?>
         <h6 class = "dropdown-footer">
         <a href = "profile.php" class = "btn btn-text-white" style ="color:blue;">View All Message</a></h6>
  </div>
 

</div>

</li>

 
    <li class="nav-item dropdown" id="dropdown">
      <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];
                             $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                        ?>
	 
 
  <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2" >'; ?><?php echo $_SESSION["Name"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="profile.php"><i class ="fa fa-user"></i>&nbsp;Profile</a>
          <a class="dropdown-item" href="cart.php"><i class = "fa fa-shopping-cart"></i>&nbsp;Cart</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"onclick="return  confirm('Are you sure you want to log out')"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
        </div>
      </li>
   
    </ul>
  </div>
</nav>


<!--card container-->
<form method = "POST" action="insert-order.php" >

<div class="card">
    <div class="row">
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."'  && cart_status ='Added'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
        <div class="col-md-8 cart">
            <div class="title">
                <div class="row">
                    <div class="col">
                        <h4><b>Shopping Cart</b></h4>
                        <p class = "note"><span>Note: You can only checkout product one by one</span></p>
                    </div>
                    <div class="col align-self-center text-right text-muted">Added Items &nbsp;<strong><?php echo ($row);?></strong></div>
                </div>
            </div>
            <?php 
      include 'dbconn.php';

			$query = "select *from cart where Fullname = '".$_SESSION['Name']."' && cart_status ='Added' LIMIT 1";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
            <div class="row border-top border-bottom">
                <div class="row main align-items-center">
                <input type = "hidden" value = "<?php echo $_SESSION['Name'];?>" name = "fullname"/>
                    <div class="col-2">
                 <?php echo $row['product_code']?>
                
                  </div>
                
                    <div class="col">
                        <div class="row text-muted"><input type = "hidden" value = "<?php echo $row['product_name'];?>"name = "product_name"/></div>
                        <div class="row"><?php echo $row['product_name'];?></div>
                    </div>
                   
                    <div class="col" id = "qty"><input type = "hidden" value = "<?php echo $row['quantity'];?>"name = "quantity"/><?php echo $row['quantity'];?></div>
                    <div class="col" id ="price"><input type = "hidden" value = "<?php echo $row['price'];?>"name = "price"/>₱ <?php echo $row['price'];?> 
                    <input type = "hidden" value = "<?php echo $row['Address'];?>"name = "address"/>
                    <input type = "hidden" value = "<?php echo $row['Contact_number'];?>"name = "contact"/>
                    <input type = "hidden" value = "<?php echo $row['product_available'];?>"name = "product_available"/>
                    <input type = "hidden" value = ""name = "courier"/>
                    <form method = "POST" action = "cancel-order.php">
                    <span class="close"><a href="cancel-order.php?cart_id=<?php echo $row['cart_id']; ?>" class = "btn btn-danger">Delete</a></span></div>
          </form>
                </div>
            </div>
            <?php } ?>
            <div class="back-to-shop"><a href="aice.php">&leftarrow;<span class="text-muted">Back to shop</span></a></div>
        </div>
        <div class="col-md-4 summary">
            <div>
                <h5><b>Summary</b></h5>
            </div>
            <hr>
          
            <div class="row">
                <div class="col" style="padding-left:0;"></div>
               
                <div class="col text-right"></div>
            </div>
           
            <?php 
      include 'dbconn.php';

			$query = "select *from aice_login where Name = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
                <p>SHIPPING</p> <select>
                    <option class="text-muted"><strong>Free</strong></option>
                </select>
                <p>Billing Address<span> &nbsp;<strong><?php echo $row['Address'];?></strong></span></p>
          
            <?php } ?>

            <?php
          
              $total = 0; 
            
              include 'dbconn.php'; 
              $query = "select *from cart where Fullname = '".$_SESSION['Name']."'  && cart_status ='Added' LIMIT 1";
              $result = mysqli_query($link,$query);
while($data = mysqli_fetch_assoc($result))
    {   
        $quantity = $data['quantity'];
        $price = $data['price'];
        $total = $total + ($data["quantity"] * $data["price"]);  

       
       
    


            ?>
       
           
            <div class="row" style="border-top: 1px solid rgba(0,0,0,.1); padding: 2vh 0;">
                <div class="col">TOTAL PRICE</div>
                <div class="col text-right"><input type = "hidden" value = "<?php echo $total; ?>"name = "total"/>₱  <?php echo $total; ?></div>
                <input type = "hidden" value = "Pending" name = "status"/>
            <input type = "hidden" name = "cart" value = "<?php echo $data['cart_id'];?>"/>
            <input type="hidden"  value="Ordered" name= "cart_status" />  
            </div> <button type = "submit" name = "submit" class="btn-checkout" onclick="return  confirm('Are you sure you want to check out ?')">CHECKOUT</button>
            <?php } ?>
        </div>
     
    
    </div>
</div>   
  </form>


    <footer class="footer-distributed">

        <div class="footer-right">

            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            

        </div>

        <div class="footer-left">

            <p class="footer-links">
            <a class="link-1" href="aice.php">Home</a>

			

<a href="map.php">Map</a>



<a href="aboutus.php">About us</a>
            </p>

            <p>Aice Ice Cream &copy; 2021 &nbsp;For more question email @naitsirhcailada0024@gmail.com</p>
        </div>

    </footer>
    </body>

</html>
