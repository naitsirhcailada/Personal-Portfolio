<head>

<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen"/>
<!------ Include the above in your HEAD tag ---------->

<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
</head>
<body>
<?php include 'navbar.php';?>
<div class="aboutus-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="aboutus">
                        <h2 class="aboutus-title">About Us</h2>
                        <p class="aboutus-text">AiceBrands Ice Cream Philippines Inc.Company Profile
AiceBrand started in Singapore in 2014. Our first market was in Indonesia. In the year of 2018, Aicewas newly established in the Philippines. We have provided tens of thousands of job opportunities, helped over100,000 low-income families to increase their income</p>
                       
                        <p class="aboutus-text"></p>
                        <a class="aboutus-more" href="#">read more</a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="aboutus-banner">
                        <img src="http://themeinnovation.com/demo2/html/build-up/img/home1/about1.jpg" alt="">
                    </div>
                </div>
                <div class="col-md-5 col-sm-6 col-xs-12">
                    <div class="feature">
                        <div class="feature-box">
                            <div class="clearfix">
                                <div class="iconset">
                                    <span class="glyphicon glyphicon-cog icon"></span>
                                </div>
                                <div class="feature-content">
                                    <h4>Aice Mission</h4>
                                    <p>To create a better future.

To provide healtier and tastier ice cream.

To offer more job opportunities.</p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-box">
                            <div class="clearfix">
                                <div class="iconset">
                                    <span class="glyphicon glyphicon-cog icon"></span>
                                </div>
                                <div class="feature-content">
                                    <h4>Aice Vision</h4>
                                    <p>In the future, AICE will continue to invest from the market to the factory, based in Asia, and bring the beauty of ice cream to every corner of the world. With the wish of creating a better future, we will provide more and more job opportunities and contribute more to the society.</p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-box">
                            <div class="clearfix">
                                <div class="iconset">
                                    
                                </div>
                                <div class="feature-content">
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'footer.php';?>
</body>
</html>