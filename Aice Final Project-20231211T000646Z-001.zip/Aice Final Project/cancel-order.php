<?php

include "dbconn.php"; // Using database connection file here

$cart_id = $_GET['cart_id']; // get id through query string

$del = mysqli_query($link,"delete from cart where cart_id = '$cart_id'"); // delete query

if($del)
{
    mysqli_close($link); // Close connection
    header("location:cart.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>