<?php 

session_start();



    $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['updateprofile']))
	{
		$user_ID = $_SESSION['user_ID'];
		$username = mysqli_real_escape_string($_POST['username']);
		$Name = mysqli_real_escape_string($_POST['Name']);
		$Contact_number =mysqli_real_escape_string($_POST['Contact_number']);
		$user_email =mysqli_real_escape_string($_POST['user_email']);
        $Address =mysqli_real_escape_string($_POST['Address']);
        $birthdate =mysqli_real_escape_string($_POST['birthdate']);

		$query = " update aice_login set username = '".$username."', Name='".$Name."',Contact_number='".$Contact_number."',user_email='".$user_email."',Address='".$Address."' ,birthdate='".$birthdate."'  where user_ID='".$user_ID."'";
		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:profile.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}

?>
