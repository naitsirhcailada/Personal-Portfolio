<?php
session_start();

?>
<?php 
 if(!isset($_SESSION['user_ID'])){
  header("location:logout.php");
 }
?>



<!doctype html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   
    <link href="https://fonts.googleapis.com/css2?family=Hind+Madurai:wght@600&family=Overpass:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/profile.css" type="text/css" media="screen" />
</head>
<title>Aice Nasugbu Branch - Profile</title>
<body>
<!--Navbar-->

<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="aice.php">Aice</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" class ="navbar-txt"href="aice.php">Home <span class="sr-only">(current)</span></a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link " href="map.php"  >Map</a>
      </li>

     
      <form class="form-inline my-2 my-lg-0" method = "POST" action = "aice.php">
      <input class="form-control mr-sm-2" id=  "search"type="search" placeholder="Search" aria-label="Search" name ="search">
      <button class="btn btn-primary my-2 my-sm-0" type="submit" >Search</button>
    </form>
    <?php 
      include 'dbconn.php';
			$query = "select *from aice_product";
		  $result = mysqli_query($link,$query);
          $row = mysqli_fetch_assoc($result)
  ?>
     <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."' && cart_status != 'Ordered'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
<li class="nav-item">
  <a class="nav-link" href = "cart.php"><i class="fas fa-shopping-cart" ><span class="badge"><?php echo ($row);?></span></i></a>
</li>

<?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);
      include 'dbconn.php';
			$query = "select *from aice_order  where Name = '".$_SESSION['Name']."' && notif ='unread'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
          $rows= mysqli_fetch_assoc($result);
 ?>
<li class="nav-item">
<div class="dropdown" id=  "ordernotif">

  <button class="btn btn-outline-secondary dropdown-toggle" type="button" name= "submit" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-bell"><span class = "badge"><?php echo ($row);?></span></i>
  </button>
  
  <form action = "updatenotif.php" method = "POST">
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">


   
      <input type ="hidden" name = "order_id" value = "<?php echo $rows['order_id'];?>"/>
      <input type ="hidden" name = "clearnotif" value = "read"/>
      <h6 class="dropdown-header">
    <button type = "submit" name = "updatenotif" class = "notif" <?php if ($rows['notif'] !== 'unread'){  ?> disabled <?php   } ?>>Clear Notifications<br><?php if($rows['notif'] !== 'unread'){ echo'No New Notifications';}?></button></h6>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);

      include 'dbconn.php';
      
			$query = "select *from aice_order  where Name = '".$_SESSION['Name']."' && notif ='unread'";
		  $result = mysqli_query($link,$query);
        
          while($rows= mysqli_fetch_assoc($result)){


 ?>   
           
           <p class = "dropdown-body"><small>Order No:<strong><?php echo $rows["order_id"]; ?></strong>&nbsp;is &nbsp;<strong><?php echo $rows["Status"]; ?></strong></small></p>
         
      

    
  
         <?php } ?>
         <h6 class = "dropdown-footer">
         <a href = "profile.php" class = "btn btn-text-white" style ="color:blue;">See All Notifications</a></h6>
  </div>
 

</div>

</li>
<?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);
      include 'dbconn.php';
			$query = "select *from aice_msg  where receiver = '".$_SESSION['user_email']."' && msg_status ='unread'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
          $rows= mysqli_fetch_assoc($result);
 ?>
<li class="nav-item">
<div class="dropdown" id = "msgnotif" >

  <button class="btn btn-outline-secondary dropdown-toggle" type="button" name= "submit" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-comment-alt"><span class = "badge"><?php echo ($row);?></span></i>
  </button>
  
  <form action = "updatemsg.php" method = "POST">
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">


   
      <input type ="hidden" name = "msg_id" value = "<?php echo $rows['msg_id'];?>"/>
      <input type ="hidden" name = "clearnotif" value = "read"/>
      <h6 class="dropdown-header">
    <button type = "submit" name = "updatenotif" class = "notif" <?php if ($rows['msg_status'] !== 'unread'){  ?> disabled <?php   } ?>>Clear Notifications<br><?php if($rows['msg_status'] == 'read'){ echo'No New Notifications';}?></button></h6>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);

      include 'dbconn.php';
      
			$query = "select *from aice_msg WHERE receiver = '".$_SESSION['user_email']."' && msg_status ='unread'";
		  $result = mysqli_query($link,$query);
        
          while($rows= mysqli_fetch_assoc($result)){


 ?>   
           
           <p class = "dropdown-body"><strong><?php echo $rows["Name"]; ?></strong><span class = "time">-Sent a message-<br><?php echo $rows['msg_time'];?></span><br>
           </p><br>
         
      

            
  
         <?php } ?>
         <h6 class = "dropdown-footer">
         <a href = "profile.php" class = "btn btn-text-white" style ="color:blue;">View All Message</a></h6>
  </div>
 

</div>

</li>


    <li class="nav-item dropdown" id="dropdown" name = "fullname">
      <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];
                             $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                        ?>
	 
 
  <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2" >'; ?> <?php echo $_SESSION["Name"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="profile.php"><i class ="fa fa-user"></i>&nbsp; Profile</a>
          <a class="dropdown-item" href="cart.php"><i class = "fa fa-shopping-cart"></i>&nbsp;Cart</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"onclick="return  confirm('Are you sure you want to log out')"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
        </div>
      </li>
   
   
    </ul>

  </div> <!--Collapase navbar-->
</nav>

<body>
<div class="container">
  
    <div class="row profile">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<!-- SIDEBAR USERPIC -->
				<div class="profile-userpic">
                <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user">'; ?>
				</div>
				<!-- END SIDEBAR USERPIC -->
				<!-- SIDEBAR USER TITLE -->
				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
					<?php echo $_SESSION['Name'];?>
					</div>
                    <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];

                            
                            $query = "SELECT *FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                            ?>

					<div class="profile-usertitle-job">
					<?php echo $row['Type'];?>
          <?php
          
          $total = 0; 
        
          include 'dbconn.php';
          $query = "select *from aice_order where Name = '".$_SESSION['Name']."' ";
          $result = mysqli_query($link,$query);
while($data = mysqli_fetch_assoc($result))
{   
    $quantity = $data['quantity'];
    $price = $data['price'];
    $total = $total + ($data["quantity"] * $data["price"]);  

   
   
}


        ?>
          <form method = "POST" action="changeprofile.php" enctype="multipart/form-data">
                                    
                                    <input type="file" name = "avatar" class="form-control" id="customFile" required />
                                    <input type = "hidden" name="user_ID" value = "<?php echo $row['user_ID'];?>"/>
                                    <button type="submit" class = "btn btn-success" name= "update">Change Profile</button><br><br>
                                    </form>
                            	<p> Total of sold items: &nbsp;₱<?php echo $total; ?></p>
					</div>
				</div>
				<!-- END SIDEBAR USER TITLE -->
				<!-- SIDEBAR BUTTONS -->
				<div class="profile-userbuttons">
					<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal<?php echo $row['user_ID'];?>">Update Profile</button>
				
				</div>
				<!-- END SIDEBAR BUTTONS -->
				<!-- SIDEBAR MENU -->
   
                     <div class="col-sm-6">
                         <div class="col-xs-3">
					<!-- Nav tabs -->
                    <ul class="nav nav-tabs tabs-left">
                    <li><a href="#home" class="nav-link" data-toggle="tab"><i class="fas fa-user mr-2"></i>About Me</a>

                    </li>
                    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from aice_msg  where receiver = '".$_SESSION['user_email']."' && msg_status = 'unread'";
		  $result = mysqli_query($link,$query);
          $notif = mysqli_num_rows($result);
          $rows = mysqli_fetch_assoc($result)
          ?>
      
      <li><a href="#change" class="nav-link" data-toggle="tab"><i class="fas fa-user mr-2"></i>Change Password</a>

</li>
                    <li><a href="#settings" class="nav-link" data-toggle="tab" ><i class="fas fa-envelope  mr-2" ></i>Chat<span class = "badge"><?php echo ($notif);?></span></a>
                    
                    </li>
    
                    <?php 
                  error_reporting(E_ALL ^ E_WARNING); 
                include 'dbconn.php';
                $query = "select *from aice_order  where Name = '".$_SESSION['Name']."' AND Status != 'Received'";
                $result = mysqli_query($link,$query);
                    $data = mysqli_num_rows($result);
 ?>
                    <li><a href="#profile" class="nav-link" data-toggle="tab"><i class="fas fa-shopping-bag mr-2"></i>My Purchase<span class = "badge"><?php echo ($data);?></span></a>

                    </li>
                    <?php 
                  error_reporting(E_ALL ^ E_WARNING); 
                include 'dbconn.php';
                $query = "select *from aice_order  where Name = '".$_SESSION['Name']."' AND Status = 'Received'";
                $result = mysqli_query($link,$query);
                    $data = mysqli_num_rows($result);
 ?>
                    <li><a href="#messages" class="nav-link" data-toggle="tab"><i class="fas fa-clock mr-2"></i>View Recent Purchases<span class = "badge"><?php echo ($data);?></span></a>

                    </li>
                   
                </ul>
			
</div>
</div>
				<!-- END MENU -->
			</div>
		</div>
       
  
		<div class="col-md-9">
            <div class="tab-content">
            <div class="tab-pane active" id="home">
         
          
  <div class="card">
      <div class = "card-header"> <h5 class="card-title">About Me</h5> </div>
      <div class="card-body">
       
     
       <div class="form-floating">
         <label class ="form-label" for ="username"> Username</label>
         <input type = "text" class = "form-control" name="username" id = "username" value = "<?php echo $row["username"];?>" style="cursor:pointer;" readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="Name"> Name</label>
         <input type = "text" class = "form-control" name = "Name" id = "Name" value = "<?php echo $row["Name"]; ?>" style="cursor:pointer;"readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="Contact_number"> Contact Number</label>
         <input type = "number" class = "form-control" name = "Contact_number"id = "Contact_number" value = "<?php echo $row["Contact_number"]; ?>" style="cursor:pointer;"readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="user_email"> Email</label>
         <input type = "email" class = "form-control" name = "user_email"id = "user_email" value = "<?php echo $row["user_email"]; ?>" style="cursor:pointer;"readonly/></p>
      </div>
      <div class="form-floating">
         <label class ="form-label" for ="Address"> Current Address</label>
         
         <input type = "text" class = "form-control"name = "Address" id = "Address" value = "<?php echo $row["Address"]; ?>" style="cursor:pointer;"readonly/></p>
       
        </div>
      <div class="form-floating">
         <label class ="form-label" for ="birthdate"> Birth Date</label>
         <input type = "date" class = "form-control" name = "birthdate"id = "birthdate" value = "<?php echo $row["birthdate"]; ?>" style="cursor:pointer;" readonly/></p>
      </div>

      </div>
      <div class = "card-footer">
      <input type = "hidden" name = "user_ID" value = "<?php echo $row['user_ID'];?>"/>
    
      
    </div>

      </div>
     

    </div>
    <?php 
             include 'dbconn.php';

			 $query = mysqli_query($link,"SELECT * FROM  aice_login ");
			 
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
         <!-- Modal -->
         <form method = "POST" action = "update-user.php" enctype="multipart/form-data">
<div class="modal fade" id="exampleModal<?php echo $row['user_ID'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">UPDATE INFO</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type = "hidden" name = "user_ID" value = "<?php echo $row['user_ID'];?>"/>
      <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt = "No Image" style ="width:40%; height:40%; border-radius:50%;" class="avatar" name="avatar" id="avatar">'; ?>
     
      <div class="form-floating ">
      <label class= "form-label"for="Name"> Name</label> 
     <input type = "text" name = "Name" class = "form-control" value = "<?php echo $row['Name'];?>"/>
     
    
     </div>
     <div class="form-floating ">
     <label class= "form-label"for="price_box">Username</label> 
     <input type = "text" name = "username" class = "form-control" value = "<?php echo $row['username'];?>"/>
    
     </div>
     <div class="form-floating" >
     <label class= "form-label"for="Contact_number">Contact Number</label> 
     <input type = "number" name = "Contact_number" class = "form-control" value = "<?php echo $row['Contact_number'];?>"/>
     
     </div>
     <div class="form-floating ">
     <label class= "form-label" for="Address">Address</label> 
     <input type = "text" name = "Address" class = "form-control" value = "<?php echo $row['Address'];?>"/>
    
     </div>
     <div class="form-floating ">
     <label class= "form-label" for="user_email">Email</label> 
     <input type = "email" name = "user_email" class = "form-control" value = "<?php echo $row['user_email'];?>"/>
    
     </div>
     <div class="form-floating ">
     <label class= "form-label" for="birthdate">Birth Date</label> 
     <input type = "date" name = "birthdate" class = "form-control" value = "<?php echo $row['birthdate'];?>"/>
     
     </div>
     <div class="form-floating ">
     <label class= "form-label" for="age">Age</label> 
     <input type = "number" name = "age" class = "form-control" value = "<?php echo $row['Age'];?>"/>
     
     </div>
     
     <h6 class="form-title">Please select Gender</h6>
                    <div class="form-radio">
                        <input type="radio" name="gender" value="male" id="male" checked="checked" />
                        <label for="male">Male</label>

                        <input type="radio" name="gender" value="Female" id="Female" />
                        <label for="Female">Female</label>

                        <input type="radio" name="gender" value="Other" id="Other" />
                        <label for="Other">Other</label>
                    </div>
                    
        
                    
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>
        <input type = "hidden" name = "user_ID" value = "<?php echo $row['user_ID'];?>"/>
        <button type="submit" name = "update" class="btn btn-outline-success" onclick="return  confirm('save the changes?')">Update</button>
      </div>
      
    </div>
  </div>

</div>
           </form> 
        <?php } ?>   

        <div class="tab-pane " id="change">
          <form method = "POST" action = "update-pass.php" onSubmit="return validate();">
          <div class = "card">
            <div class = "card-header">Change Password </div>
            <div class = "card-body">
            <div class="form-floating ">
             <label class= "form-label" for="newpsw">New Password</label> 
              <input type = "password"id ="newpsw" name = "newpsw" class = "form-control"pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required />
            </div>
            <div class="form-floating ">
             <label class= "form-label" for="confirm">Confirm New Password</label> 
              <input type = "password" id= "confirm" name = "confirm" class = "form-control" required/>
            </div>
            <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>
        <input type = "hidden" name = "user_ID" value = "<?php echo $_SESSION['user_ID'];?>"/>
        <button type="submit" name = "update" class="btn btn-outline-success" onclick="return  confirm('save the changes?')">Change Password</button>
      </div>

            </div>
          </div>
       </form>
       </div>
            <div class="tab-pane " id="profile">
         
    <div class="card">
    <div class="title">Purchase Reciept 
    
    <a href = "export.php" target="_blank"> <button type ="button" class = "btn btn-warning"><i class="fas fa-receipt"></i>Print Reciept</button></a>
    <p class = "note">Note: Don't forget to click the order received once you receive the order</p>
    </div>
   
    <div class="info">
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_order where Name = '".$_SESSION['Name']."' && Status != 'completed' ";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
        <div class="row">
            <div class="col-7"> <span id="heading">Date</span><br> <span id="details"><strong><?php echo $row['order_time'];?></strong></span> </div>
            <div class="col-5 pull-right"> <span id="heading">Order No.</span><br> <span id="details"><strong><?php echo $row['order_id']; ?></strong></span> </div>
            <div class="col-9"> <span id="name"><strong><?php echo $row['product_name'];?> </strong></span> </div>
            <div class="col-3"> <span id="price"><strong>₱<?php echo $row['total'];?></span> <p class = "status">&nbsp;<?php echo $row['Status'];?></strong> </p></div>
            <div class="col-9"> <span id="name">Shipping</span> </div>
            <div class="col-3"> <span id="price">Free</span> </div>
            <div class="col-3"><p class = "total">Total Price ₱<big><?php echo $row['total'];?></big></p></div>

            <form method = "POST" action = "update-order-status.php">
              <input type = "hidden" value="<?php echo $row['order_id'];?>" name = "order" />
           
            <div class="col-2"><button type ="submit" id = "submit"class = "btn btn-success"<?php if ($row['Status'] !== 'To Deliver'){ ?> disabled <?php   } ?>name = "update">Order Received</button>&nbsp;
            </form>
            <button type ="button" data-toggle="modal" data-target="#trackingmodal<?php echo $row['order_id'];?>"class =" btn btn-success">Track Order</button>
          
          <form method = "POST" action = "order-completed.php">
            <input type = "hidden" name = "order" value ="<?php echo $row['order_id'];?>">
            <input type = "hidden" name = "status" value ="completed">
          &nbsp;<button type ="submit" name="update" class =" btn btn-success">Completed</button>
          </form>
        </div>
         
    </div>
   
        <?php } ?>
        
    </div>
   
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_login where Name = '".$_SESSION['Name']."' ";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
    <div class="tracking">
        <div class="title">Billing Address:<?php echo $row['Address'];?></div>
        
    </div>
<?php } ?>
    <div class="footer">
        <div class="row">
          
          
        </div>
           
        </div>
    </div>
</div>
<?php 
      include 'dbconn.php';

			$query = "select *from aice_order where Name = '".$_SESSION['Name']."' ";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
<!-- Modal -->
<div class="modal fade" id="trackingmodal<?php echo $row['order_id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tracking Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
        <ul class = "tracking">
    <li>Order No. <span class = "track"><?php echo $row['order_id'];?></span></li>
    <li>Order Time. <span class = "track"><?php echo $row['order_time'];?></span></li>
    <li>Order Status: <span class = "track"><?php echo $row['Status'];?></span></li>
    <li>Product <span class = "track"><?php echo $row['product_name'];?></span></li>
    <li>Your order is out for delivery <span class = "track"><?php echo $row['delivery_time'];?></span></li>
    <li> Product Received at <span class = "track">  <?php echo $row['date_delivered'];?></span></li>
    <li> Shipping Fee <span class = "track">  Free</span></li>
  </ul>
       
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>
<?php } ?>

            <div class="tab-pane " id="messages">
            <?php 
             include 'dbconn.php';
            
			 $query = mysqli_query($link,"SELECT * FROM  aice_order WHERE Status = 'Received' AND  Name = '".$_SESSION['Name']."' ");
			
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
         
<div class = "card" id="history-card">
  <div class = "card-header">Recent Purchase &nbsp;<span><a href="delete-order-history.php?order_id=<?php echo $row['order_id']; ?>" class = "btn btn-danger">Delete</a><p class = "note">Note: Once you delete the history of purchase it will be deleted from our database</p></span></div>
  <div class = "card-body">
          Order No:<strong><?php echo $row['order_id'];?> </strong><br>
          Product:&nbsp;<strong><?php echo $row['product_name'];?></strong><br>
          Quantity:&nbsp;<strong><?php echo $row['quantity'];?></strong><br>
        
          Total:&nbsp;<strong>₱<?php echo $row['total'];?></strong><br>
          Delivery Date: &nbsp;<strong><?php echo $row['delivery_time'];?></strong><br>
          Date Received: &nbsp;<strong><?php echo $row['date_delivered'];?></strong><br>
          Courier: &nbsp;<strong><?php echo $row['courier'];?></strong><br>
          Shipping: &nbsp;<strong>Free</strong><br>

       </div>
       </div>

<?php } ?>

            </div>
            
            <div class="tab-pane " id="settings">
       
        
         
              <form method = "POST"action = "insert-message.php">
          <div class = "card" id=  "message">
          
       <div class = "card-header">CHAT</div>
       <div class = "card-body">
       <?php 
                                    include 'dbconn.php';
                                    $qry = "select *from aice_login WHERE Name != '".$_SESSION['Name']."'  ";
                                    $results = mysqli_query($link,$qry);
                                    $rows = mysqli_fetch_array($results);
                                    ?>
                                    
                      <input type = "email" name = "select-user" class = "form-control" placeholder = "Send to email"/>
      

     <div class = "msg-form">
   
     <?php 
        include 'dbconn.php';
        
			 $query = mysqli_query($link,"SELECT * FROM  aice_msg WHERE Name = '".$_SESSION['Name']."' || receiver = '".$_SESSION['user_email']."'");
			
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
        
       
        <h5> <strong><?php if($row['receiver'] == $_SESSION['user_email']){ echo 'From:  '.$row['Name'].''; }else { echo 'You'; }?></strong> </h5>
          
       <h6 class="time-delivered"> &nbsp; </strong>&nbsp;Delivered:<?php echo $row['msg_time'];?></h6><br>
      <p>Subject: &nbsp;<strong><?php echo $row['subject'];?></strong></p>
       <?php 
       $message = $row['message'];
       if($row['Name'] == $_SESSION['Name']){
          echo '<input style="background-color:#2A6AE1; border:none; color:white; border-radius:15px; cursor:pointer;"  value = "'.$message.'" class="form-control" readonly>';
       }else{
        echo '<input style="background-color:gray; border:none; color:black;border-radius:15px; cursor:pointer;"  value = "'.$message.'" class="form-control" readonly>';
       }
       ?>
     
        <input type = "hidden"  name = "msg_id" value ="<?php echo $row['msg_id'];?>"/>
       
      
      

     
        <a href= "delete-msg.php?msg_id=<?php echo $row['msg_id']; ?>">Remove</a>
       <small><p >Sent</p></small>
     
       <?php } ?>
        </div>
       </div>
      
       <div class = "card-footer">
         <input type="hidden" value ="<?php echo $_SESSION['Name'];?>" name ="Name"/>
         <input type="hidden" value ="<?php echo $_SESSION['Type'];?>" name ="Type"/>
      
         <input type = "hidden" name = "stat" value = "unread" />
         <input type = "text" class ="form-control" name = "subject" placeholder="Subject" style = "margin-bottom:0.5rem;"/>
       <textarea placeholder=  "Aa" class = "form-control"  rows = "6" cols = "60" name="message"></textarea><br>
         <button type = "submit" name = "send" class = "btn btn-primary"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
     
       </div>
       </div>
     

            </div>
       </form>
     


            </div>
		</div>
       
	</div>
  
</div>

<?php include 'footer.php'; ?>


    </body>
  
        </html>
        <script>
            $('.nav-tabs > li > a').click(function () {
    $(this).tab('show');
});
            </script>
             <script>
        function validate(){

            var a = document.getElementById("newpsw").value;
            var b = document.getElementById("confirm").value;
            if (a!=b) {
               alert("Passwords do no match");
               return false;
            }
        }
     </script>
         
  