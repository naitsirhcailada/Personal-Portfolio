<?php 

session_start();



    $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['updatenotif']) )
	{
		
		$msg_id = $_POST['msg_id'];
       
		$msg_status =   $_POST['clearnotif'];
		
		$query = " update aice_msg set`msg_status` = '$msg_status'";

		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:aice.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}
	
?>
