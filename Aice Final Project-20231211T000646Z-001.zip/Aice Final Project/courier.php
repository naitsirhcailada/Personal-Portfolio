<?php
session_start();
?>
<?php 

if(!isset($_SESSION['user_ID'])){
 header("location:../../logout.php");
}
?>
<?php 

include 'dbconn.php';
$query = "select *from aice_order where courier = '".$_SESSION['Name']."' ";
$results = mysqli_query($link,$query);

?>

<!doctype html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link href="css/courier.css" rel="stylesheet">
    
    <title>Aice Nasugbu Branch - Courier</title>
</head>
<body>
  <!--Navbar-->

  <nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="courier.php">Aice</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
 


    <li class="nav-item dropdown" id="dropdown">
      <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];
                             $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                        ?>
	 
 
  <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2" >'; ?> <?php echo $_SESSION["Name"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="courierprofile.php"><i class ="fa fa-user"></i>&nbsp; Profile</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
        </div>
      </li>
   
   
    </ul>

  </div> <!--Collapase navbar-->
</nav>


<body>
<div class ="container">

<div class="card">
                            <div class="card-body">
                            <h4 class="card-title"><strong>Assigned Orders</strong></h4>
                               
                                <div class="table-responsive">
                                    <table class="table user-table no-wrap">
                                        <thead>
                                            <tr>
                                                <th class="border-top-0">Order Number</th>
                                                
                                                <th class="border-top-0"> Product Name</th>
                                                <th class="border-top-0">Quantity</th>
                                                <th class="border-top-0">Price</th>
                                                <th class="border-top-0">Total</th>
                                                <th class="border-top-0">Name</th>
                                                <th class="border-top-0">Status</th>
                                                <th class="border-top-0">Billing Address</th>
                                                <th class="border-top-0">Contact Number</th>
                                                <th class="border-top-0">Action</th>
                                               
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                         
                                <?php
	                                while($rows = mysqli_fetch_assoc($results))
                                    
                            	{
                                ?>
                               
                                
	                                <tr>
		                                <td><?php echo $rows['order_id']?></td>
		                                <td><?php echo $rows['product_name']?></td>
		                                <td><?php echo $rows['quantity']?></td>
                                    <td><?php echo $rows['price']?></td>
                                    <td><?php echo $rows['total']?></td>
		                                <td><?php echo $rows['Name']?></td>
                                    <td><?php echo $rows['Status']?></td>
                                    <td><?php echo $rows['Address']?></td>
                                    <td><?php echo $rows['Contact_number']?></td>
                                    <td><button type = "button" class = "btn btn-primary"data-toggle="modal" data-target="#exampleModal<?php echo $rows['order_id'];?>">Deliver Order</button></td>
	                                </tr>
	                            <?php
                            	}
	                            ?>
                                                
                                         
                                        </tbody>
                                       
                                    </table>
                                </div>
                            </div>

                            <?php 
             include 'dbconn.php';

			 $query = mysqli_query($link,"SELECT * FROM  aice_order ");
			 
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
          
       
       <!-- Modal -->
     <form method = "POST" action="update-order.php">
<div class="modal fade" id="exampleModal<?php echo $row['order_id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
     
        <h5 class="modal-title" id="exampleModalLabel">Order Information of <strong><?php echo $row['Name'];?></strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>
          
        </button>
      </div>
      <div class="modal-body">
      
    
      <div class = "info">
      
     
      
      <input type = "text" class = "form-control" value = "Order Number &nbsp;(<?php echo $row['order_id'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Product Name &nbsp;(<?php echo $row['product_name'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Reseller Name &nbsp;(<?php echo $row['Name'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Quantity &nbsp;(<?php echo $row['quantity'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Price &nbsp;(<?php echo $row['price'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Total &nbsp;(<?php echo $row['total'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Recent Address &nbsp;(<?php echo $row['Address'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Contact Number &nbsp;(<?php echo $row['Contact_number'];?>)" readonly>
      <select name= "select-status" id="standard-select"class = "btn btn-success dropdown-toggle" required>
                                                          <option value = "" selected disabled><?php echo $row['Status'];?></option>
                                                        <option value="To Deliver">To Deliver</option>
                                                      </select>
   
           </div>
      </div>
     
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type = "hidden" name = "order" value="<?php echo $row['order_id'];?>"/>
        <button type = "submit" class = "btn btn-success" name = "Update" ><i class="fa fa-refresh" aria-hidden="true"></i>Order Completed</button>
        
        
      </div>
    </div>
  </div>
</div>
</form>
<?php } ?> 

</div> <!--container-->



</body>
</html>