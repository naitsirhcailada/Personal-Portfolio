<?php
session_start();
?>
<?php 

if(!isset($_SESSION['user_ID'])){
 header("location:../../logout.php");
}
?>
<?php 

include 'dbconn.php';
$query = "select *from aice_order where courier = '".$_SESSION['Name']."'&& Status != 'Received' ";
$results = mysqli_query($link,$query);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>Courier- Aice Nasugbu</title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a><h3>COURIER CHAT</h3>
      </div>
      <div class="side-inner">
        <?php 
        include 'dbconn.php';
        $user_ID=$_SESSION['user_ID'];
         $query = "SELECT  *FROM `aice_login` WHERE user_ID='".$user_ID."'";
        $result = mysqli_query($link,$query);
        $row = $result->fetch_assoc();
    ?>
    <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <div class="profile">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="img-fluid" >'; ?> 
          <h3 class="name"> <?php echo $_SESSION["Name"]; ?></h3>
          <span class="country"><?php echo $row['Type'];?></span>
        </div>

        
        <div class="nav-menu">
          <ul>
            <li>
              <a href="courier.php"  aria-expanded="false" aria-controls="collapseOne" class="collapsible">
                <span class="icon-home mr-3"></span>Home
              </a>
              
            </li>
            
           
            <li><a href="courier-profile.php"><span class="icon-location-arrow mr-3"></span>Profile</a></li>
            <li><a href="changepass.php"><i class="fa fa-key  mr-3" aria-hidden="true"></i>Change Password</a></li>
            <li><a href="courier-message.php"><i class="fas fa-envelope mr-3"></i>Message</a></li>
            <li><a href="logout.php"><span class="icon-sign-out mr-3"></span>Sign out</a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
      <div class="site-section">
        <div class="container">
          <div class="row justify-content-center">





            <div class="col-md-9">
              <div class="row">
              <form method = "POST"action = "insert-message.php">
          <div class = "card" id=  "message">
          
       <div class = "card-header">CHAT</div>
       <div class = "card-body">
       <?php 
                                    include 'dbconn.php';
                                    $qry = "select *from aice_login WHERE Name != '".$_SESSION['Name']."'  ";
                                    $results = mysqli_query($link,$qry);
                                    $rows = mysqli_fetch_array($results);
                                    ?>
                                    
                      <input type = "email" name = "select-user" class = "form-control" placeholder = "Send to email"/>
      

     <div class = "msg-form">
   
     <?php 
        include 'dbconn.php';
        
			 $query = mysqli_query($link,"SELECT * FROM  aice_msg WHERE Name = '".$_SESSION['Name']."' || receiver = '".$_SESSION['user_email']."'");
			
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
        
       
        <h5> <strong><?php if($row['receiver'] == $_SESSION['user_email']){ echo 'From:  '.$row['Name'].''; }else { echo 'You'; }?></strong> </h5>
          
       <h6 class="time-delivered"> &nbsp; </strong>&nbsp;Delivered:<?php echo $row['msg_time'];?></h6><br>
      <p>Subject: &nbsp;<strong><?php echo $row['subject'];?></strong></p>
       <?php 
       $message = $row['message'];
       if($row['Name'] == $_SESSION['Name']){
          echo '<input style="background-color:#2A6AE1; border:none; color:white; border-radius:15px; cursor:pointer;"  value = "'.$message.'" class="form-control" readonly>';
       }else{
        echo '<input style="background-color:gray; border:none; color:black;border-radius:15px; cursor:pointer;"  value = "'.$message.'" class="form-control" readonly>';
       }
       ?>
     
        <input type = "hidden"  name = "msg_id" value ="<?php echo $row['msg_id'];?>"/>
       
      
      

     
        <a href= "delete-msg.php?msg_id=<?php echo $row['msg_id']; ?>">Remove</a>
       <small><p >Sent</p></small>
     
       <?php } ?>
        </div>
       </div>
      
       <div class = "card-footer">
         <input type="hidden" value ="<?php echo $_SESSION['Name'];?>" name ="Name"/>
         <input type="hidden" value ="<?php echo $_SESSION['Type'];?>" name ="Type"/>
      
         <input type = "hidden" name = "stat" value = "unread" />
         <input type = "text" class ="form-control" name = "subject" placeholder="Subject" style = "margin-bottom:0.5rem;"/>
       <textarea placeholder=  "Aa" class = "form-control"  rows = "6" cols = "60" name="message"></textarea><br>
         <button type = "submit" name = "send" class = "btn btn-primary"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
     
       </div>
       </div>
     

            </div>
       </form>
     


            </div>
		</div>
       
	</div>
        </div>
        </div>
        </div>
        </div>
      </div>  
    </main>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>