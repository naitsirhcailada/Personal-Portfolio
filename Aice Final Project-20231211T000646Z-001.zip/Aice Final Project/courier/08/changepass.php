<?php
session_start();
?>
<?php 

if(!isset($_SESSION['user_ID'])){
 header("location:../../logout.php");
}
?>
<?php 

include 'dbconn.php';
$query = "select *from aice_order where courier = '".$_SESSION['Name']."' ";
$results = mysqli_query($link,$query);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>Courier- Aice Nasugbu</title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
       <span></span>
            </a> <h3 >COURIER PROFILE</h3>
      </div>
      <div class="side-inner">
        <?php 
        include 'dbconn.php';
        $user_ID=$_SESSION['user_ID'];
         $query = "SELECT  *FROM `aice_login` WHERE user_ID='".$user_ID."'";
        $result = mysqli_query($link,$query);
        $row = $result->fetch_assoc();
    ?>
    <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <div class="profile">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="img-fluid" >'; ?> 
          <h3 class="name"> <?php echo $_SESSION["Name"]; ?></h3>
          <span class="country"><?php echo $row['Type'];?></span>
        </div>

        
        <div class="nav-menu">
          <ul>
            <li>
              <a href="courier.php"  aria-expanded="false" aria-controls="collapseOne" class="collapsible">
                <span class="icon-home mr-3"></span>Home
              </a>
              
            </li>
            
           
            <li><a href="#"><span class="icon-location-arrow mr-3"></span>Profile</a></li>
            <li><a href="changepass.php"><i class="fa fa-key  mr-3" aria-hidden="true"></i>Change Password</a></li>
            <li><a href="courier-message.php"><i class="fas fa-envelope mr-3"></i>Message</a></li>
            <li><a href="logout.php"><span class="icon-sign-out mr-3"></span>Sign out</a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
      <div class="site-section">
        <div class="container">
          <div class="row justify-content-center">





            <div class="col-md-9">
              <div class="row">


             

       <div class="card">
       <form method = "POST" action = "update-pass.php" onSubmit="return validate();">
  <h5 class="card-header">Change Password</h5>
  <div class="card-body">
  <div class="form-floating ">
             <label class= "form-label" for="newpsw">New Password</label> 
              <input type = "password"id ="newpsw" name = "newpsw" class = "form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required />
            </div>
            <div class="form-floating ">
             <label class= "form-label" for="confirm">Confirm New Password</label> 
              <input type = "password" id= "confirm" name = "confirm" class = "form-control" required/>
            </div>
            <input type = "hidden" name = "user_ID" value = "<?php echo $_SESSION['user_ID'];?>"/>
        <button type="submit" name = "update" class="btn btn-outline-success" onclick="return  confirm('save the changes?')">Change Password</button>
  </div>
  </form>
</div>



</div>
</div>
</div>
                   
      


      </div>  

    </main>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
  
</html>
<script>
        function validate(){

            var a = document.getElementById("newpsw").value;
            var b = document.getElementById("confirm").value;
            if (a!=b) {
               alert("Passwords do no match");
               return false;
            }
        }
     </script>
         