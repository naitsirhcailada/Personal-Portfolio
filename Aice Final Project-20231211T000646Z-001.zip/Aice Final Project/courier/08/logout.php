<?php
session_start();
unset($_SESSION["user_ID"]);
unset($_SESSION["Name"]);
unset($_SESSION['Type']);
unset($_SESSION['user_email']);

session_destroy();
header("Location:../../index.php");
?>