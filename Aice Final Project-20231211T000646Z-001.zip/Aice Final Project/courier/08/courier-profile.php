<?php
session_start();
?>
<?php 

if(!isset($_SESSION['user_ID'])){
 header("location:../../logout.php");
}
?>
<?php 

include 'dbconn.php';
$query = "select *from aice_order where courier = '".$_SESSION['Name']."' ";
$results = mysqli_query($link,$query);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>Courier- Aice Nasugbu</title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
       <span></span>
            </a> <h3 >COURIER PROFILE</h3>
      </div>
      <div class="side-inner">
        <?php 
        include 'dbconn.php';
        $user_ID=$_SESSION['user_ID'];
         $query = "SELECT  *FROM `aice_login` WHERE user_ID='".$user_ID."'";
        $result = mysqli_query($link,$query);
        $row = $result->fetch_assoc();
    ?>
    <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <div class="profile">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="img-fluid" >'; ?> 
          <h3 class="name"> <?php echo $_SESSION["Name"]; ?></h3>
          <span class="country"><?php echo $row['Type'];?></span>
        </div>

        
        <div class="nav-menu">
          <ul>
            <li>
              <a href="courier.php"  aria-expanded="false" aria-controls="collapseOne" class="collapsible">
                <span class="icon-home mr-3"></span>Home
              </a>
              
            </li>
            
           
            <li><a href="#"><span class="icon-location-arrow mr-3"></span>Profile</a></li>
            <li><a href="changepass.php"><i class="fa fa-key  mr-3" aria-hidden="true"></i>Change Password</a></li>
            <li><a href="courier-message.php"><i class="fas fa-envelope mr-3"></i>Message</a></li>
            <li><a href="logout.php"><span class="icon-sign-out mr-3"></span>Sign out</a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
      <div class="site-section">
        <div class="container">
          <div class="row justify-content-center">





            <div class="col-md-9">
              <div class="row">

              <div class="card user-card-full" style="border:1px solid blueviolet;">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25"> <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="img-radius" >'; ?> </div>
                                <h6 class="f-w-600"><?php echo $row['Name'];?></h6>
                                <h6 class="f-w-600"><?php echo $row['username'];?></h6>
                                <form method = "POST" action="changeprofile.php" enctype="multipart/form-data">
                                    
                                    <input type="file" name = "avatar" class="form-control" id="customFile" required />
                                    <input type = "hidden" name="user_ID" value = "<?php echo $row['user_ID'];?>"/>
                                    <button type="submit" class = "btn btn-success" name= "update">Change Profile Picture</button><br><br>
                                    </form>
                                <p><?php echo $row['Type'];?></p> <button type = "button" style="border:none;" class="btn btn-outline-primary" data-toggle="modal" data-target="#exampleModal<?php echo $row['user_ID'];?>" style= "color:white;"><i class=" mdi mdi-square-edit-outline feather icon-edit m-t-10 f-16"></i></button>
                                
                                   
                              </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email</p>
                                        <h6 class="text-muted f-w-400"><?php echo $row['user_email'];?></h6>
                                        <p class="m-b-10 f-w-600">Address</p>
                                        <h6 class="text-muted f-w-400"><?php echo $row['Address'];?></h6>
                                        <p class="m-b-10 f-w-600">Gender</p>
                                        <h6 class="text-muted f-w-400"><?php echo $row['Gender'];?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Phone</p>
                                        <h6 class="text-muted f-w-400"><?php echo $row['Contact_number'];?></h6>
                                        <p class="m-b-10 f-w-600">Age</p>
                                        <h6 class="text-muted f-w-400"><?php echo $row['Age'];?></h6>
                                        <p class="m-b-10 f-w-600">Birth Date</p>
                                        <h6 class="text-muted f-w-400"><?php echo $row['birthdate'];?></h6>
                                    </div>
                                  
                                    
                                   
                               
                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </div>
        </div>
        </div>

        <?php 
             include 'dbconn.php';

			 $query = mysqli_query($link,"SELECT * FROM  aice_login ");
			 
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
         <!-- Modal -->
         <form method = "POST" action = "update-courier.php" >
<div class="modal fade" id="exampleModal<?php echo $row['user_ID'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">UPDATE INFO</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <input type = "hidden" name = "user_ID" value = "<?php echo $row['user_ID'];?>"/>
      <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt = "No Image" style ="width:40%; height:40%; border-radius:50%;" class="avatar" name="avatar" id="avatar">'; ?>
      
      <div class="form-floating ">
     <input type = "text" name = "Name" class = "form-control" value = "<?php echo $row['Name'];?>"/>
     
     <label class= "form-label"for="Name"> Name</label> 
     </div>
     <div class="form-floating ">
     <input type = "text" name = "username" class = "form-control" value = "<?php echo $row['username'];?>"/>
     <label class= "form-label"for="price_box">Username</label> 
     </div>
     <div class="form-floating" >
     <input type = "number" name = "Contact_number" class = "form-control" value = "<?php echo $row['Contact_number'];?>"/>
     <label class= "form-label"for="Contact_number">Contact Number</label> 
     </div>
     <div class="form-floating ">
     <input type = "text" name = "Address" class = "form-control" value = "<?php echo $row['Address'];?>"/>
     <label class= "form-label" for="Address">Address</label> 
     </div>
     <div class="form-floating ">
     <input type = "email" name = "user_email" class = "form-control" value = "<?php echo $row['user_email'];?>"/>
     <label class= "form-label" for="user_email">Email</label> 
     </div>
     <div class="form-floating ">
     <input type = "date" name = "birthdate" class = "form-control" value = "<?php echo $row['birthdate'];?>"/>
     <label class= "form-label" for="birthdate">Birth Date</label> 
     </div>
     <div class="form-floating ">
     <input type = "number" name = "age" class = "form-control" value = "<?php echo $row['Age'];?>"/>
     <label class= "form-label" for="age">Age</label> 
     </div>
     <h6 class="form-title">Please select Gender</h6>
                    <div class="form-radio">
                        <input type="radio" name="gender" value="male" id="male" checked="checked" />
                        <label for="male">Male</label>

                        <input type="radio" name="gender" value="Female" id="Female" />
                        <label for="Female">Female</label>

                        <input type="radio" name="gender" value="Other" id="Other" />
                        <label for="Other">Other</label>
                    </div>
     
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>
        <input type = "hidden" name = "user_ID" value = "<?php echo $row['user_ID'];?>"/>
        <button type="submit" name = "update" class="btn btn-outline-success" onclick="return  confirm('save the changes?')">Update</button>
      </div>
    </div>
  </div>
</div>
           </form> 
        <?php } ?>   
      


      </div>  

    </main>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
  
</html>
