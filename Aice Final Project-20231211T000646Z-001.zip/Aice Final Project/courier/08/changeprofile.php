<?php 

session_start();



    $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['update']))
	{
		$user_ID = $_POST['user_ID'];
	
        $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
	
		$query = " UPDATE aice_login SET avatar='".$avatar."'  WHERE user_ID='".$user_ID."'";
		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:courier-profile.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}

?>
