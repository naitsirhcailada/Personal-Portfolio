<?php
session_start();
?>
<?php 

if(!isset($_SESSION['user_ID'])){
 header("location:../../logout.php");
}
?>
<?php 

include 'dbconn.php';
$query = "select *from aice_order where courier = '".$_SESSION['Name']."' && Status != 'Received' && Status !='completed'";
$results = mysqli_query($link,$query);

?>
<!--?Search-->
<?php

if(isset($_POST['submit']))
{
    $valueToSearch = $_POST['search'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `aice_order` WHERE CONCAT(`order_id`, `product_name`, `Name`,`Status`,`Address`) LIKE '%".$valueToSearch."%'";
    $result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `aice_order`";
    $result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost:3307", "root", "root", "aice");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>Courier- Aice Nasugbu</title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a><h3>AICE COURIER </h3>
      </div>
      <div class="side-inner">
        <?php 
        include 'dbconn.php';
        $user_ID=$_SESSION['user_ID'];
         $query = "SELECT  *FROM `aice_login` WHERE user_ID='".$user_ID."'";
        $result = mysqli_query($link,$query);
        $row = $result->fetch_assoc();
    ?>
    <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <div class="profile">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="img-fluid" >'; ?> 
          <h3 class="name"> <?php echo $_SESSION["Name"]; ?></h3>
          <span class="country"><?php echo $row['Type'];?></span>
        </div>

        
        <div class="nav-menu">
          <ul>
            <li>
              <a href="courier.php"  aria-expanded="false" aria-controls="collapseOne" class="collapsible">
                <span class="icon-home mr-3"></span>Home
              </a>
              
            </li>
            
           
            <li><a href="courier-profile.php"><span class="icon-location-arrow mr-3"></span>Profile</a></li>
            <li><a href="changepass.php"><i class="fa fa-key  mr-3" aria-hidden="true"></i>Change Password</a></li>
            <li><a href="courier-message.php"><i class="fas fa-envelope mr-3"></i>Message</a></li>
            <li><a href="logout.php"><span class="icon-sign-out mr-3"></span>Sign out</a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
      <div class="site-section">
        <div class="container">
          <div class="row justify-content-center">





            <div class="col-md-9">
              <div class="row">
              <div class="card" style="border:1px solid blueviolet;">
                            <div class="card-body">
                            <h4 class="card-title"><strong>Assigned Orders</strong></h4>
                            
                               <div class="table-responsive">
                                    <table class="table user-table no-wrap">
                                        <thead>
                                            <tr>
                                                <th class="border-top-0">Order Number</th>
                                                
                                                <th class="border-top-0"> Product Name</th>
                                                <th class="border-top-0">Quantity</th>
                                                <th class="border-top-0">Price</th>
                                                <th class="border-top-0">Total</th>
                                                <th class="border-top-0">Name</th>
                                                <th class="border-top-0">Status</th>
                                                <th class="border-top-0">Billing Address</th>
                                                <th class="border-top-0">Contact Number</th>
                                                <th class="border-top-0">Action</th>
                                               
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                         
                                <?php
	                                while($rows = mysqli_fetch_assoc($results))
                                    
                            	{
                                ?>
                               
                                
	                                <tr>
		                                <td><?php echo $rows['order_id']?></td>
		                                <td><?php echo $rows['product_name']?></td>
		                                <td><?php echo $rows['quantity']?></td>
                                    <td><?php echo $rows['price']?></td>
                                    <td><?php echo $rows['total']?></td>
		                                <td><?php echo $rows['Name']?></td>
                                    <td><?php echo $rows['Status']?></td>
                                    <td><?php echo $rows['Address']?></td>
                                    <td><?php echo $rows['Contact_number']?></td>
                                    <td><button type = "button" class = "btn btn-primary"data-toggle="modal" data-target="#exampleModal<?php echo $rows['order_id'];?>">Deliver Order</button></td>
                                    <td><button type = "button" class = "btn btn-primary"data-toggle="modal" data-target="#addressmodal<?php echo $rows['order_id'];?>">Update Address</button></td>
	                                </tr>
	                            <?php
                            	}
	                            ?>
                                                
                                         
                                        </tbody>
                                       
                                    </table>
                                </div>
                            </div>

                            <?php 
             include 'dbconn.php';

			 $query = mysqli_query($link,"SELECT * FROM  aice_order ");
			 
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
          
       
       <!-- Modal -->
     <form method = "POST" action="update-order.php">
<div class="modal fade" id="exampleModal<?php echo $row['order_id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
     
        <h5 class="modal-title" id="exampleModalLabel">Order Information of <strong><?php echo $row['Name'];?></strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>
          
        </button>
      </div>
      <div class="modal-body">
      
    
      <div class = "info">
      
     
      
      <input type = "text" class = "form-control" value = "Order Number &nbsp;(<?php echo $row['order_id'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Product Name &nbsp;(<?php echo $row['product_name'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Reseller Name &nbsp;(<?php echo $row['Name'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Quantity &nbsp;(<?php echo $row['quantity'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Price &nbsp;(<?php echo $row['price'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Total &nbsp;(<?php echo $row['total'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Recent Address &nbsp;(<?php echo $row['Address'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Contact Number &nbsp;(<?php echo $row['Contact_number'];?>)" readonly>
      <select name= "select-status" id="standard-select"class = "btn btn-success dropdown-toggle" required>
                                                          <option value = "" selected disabled><?php echo $row['Status'];?></option>
                                                        <option value="To Deliver">To Deliver</option>
                                                      </select>
                                                    
       
           </div>
      </div>
     
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type = "hidden" name = "order" value="<?php echo $row['order_id'];?>"/>
        <button type = "submit" class = "btn btn-success" name = "Update" ><i class="fa fa-refresh" aria-hidden="true"></i>Order Completed</button>
       
       
      </div>
    </div>
  </div>
</div>
</form>
<?php } ?> 

<?php 
             include 'dbconn.php';

			 $query = mysqli_query($link,"SELECT * FROM  aice_order ");
			 
		   while	( $row  = mysqli_fetch_array($query)){
          ?>
          
       
       <!-- Modal -->
     <form method = "POST" action="update-current-address.php"  enctype="multipart/form-data">
<div class="modal fade" id="addressmodal<?php echo $row['order_id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
     
        <h5 class="modal-title" id="exampleModalLabel">Order Information of <strong><?php echo $row['Name'];?></strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>
          
        </button>
      </div>
      <div class="modal-body">
      
    
      <div class = "info">
      
     
      
      <input type = "text" class = "form-control" value = "Order Number &nbsp;(<?php echo $row['order_id'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Product Name &nbsp;(<?php echo $row['product_name'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Reseller Name &nbsp;(<?php echo $row['Name'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Quantity &nbsp;(<?php echo $row['quantity'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Price &nbsp;(<?php echo $row['price'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Total &nbsp;(<?php echo $row['total'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Recent Address &nbsp;(<?php echo $row['Address'];?>)" readonly>
      <input type = "text" class = "form-control" value = "Contact Number &nbsp;(<?php echo $row['Contact_number'];?>)" readonly>
        <input type = "file" name = "proofofdelivery"/>
                                                      
                                 

      <select name= "select-city" id="standard-select"class = "btn btn-success dropdown-toggle" required>
                                                          <option value = "" selected disabled>Select Current Address</option>
                                                          <option value="Nasugbu City">Nasugbu Trade Mark</option>
                                                        <option value="<?php echo $row['Address'];?>"><?php echo $row['Address'];?></option>
                                                      </select>
 
       
           </div>
      </div>
     
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type = "hidden" name = "order" value="<?php echo $row['order_id'];?>"/>
       
        <button type = "submit" class = "btn btn-success" name = "updateaddress" ><i class="fa fa-refresh" aria-hidden="true"></i>Update Address</button>
        </form> 
      </div>
    </div>
  </div>
</div>
</form>
<?php } ?> 

      </div>  
    </main>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>