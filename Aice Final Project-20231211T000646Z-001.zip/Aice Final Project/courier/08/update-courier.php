<?php 

session_start();



    $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['update']))
	{
		$user_ID = $_POST['user_ID'];
		$Name = $_POST['Name'];
       
		$username = $_POST['username'];
		$Contact_number = $_POST['Contact_number'];
		$Address = $_POST['Address'];
        $user_email = $_POST['user_email'];
        $birthdate = $_POST['birthdate'];
        $Age = $_POST['age'];
        $Gender = $_POST['gender'];
		$query = " UPDATE aice_login SET Name='".$Name."', username='".$username."',Contact_number='".$Contact_number."',Address='".$Address."',user_email='".$user_email."',birthdate='".$birthdate."',Age='".$Age."',Gender='".$Gender."' WHERE user_ID='".$user_ID."'";
		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:courier-profile.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}

?>
