<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3307", "root", "root", "aice");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


    
 if(isset($_POST['submit'])){


// Escape user inputs for security

$request_status = mysqli_real_escape_string($link, $_REQUEST['request_status']);
$user_email = mysqli_real_escape_string($link, $_REQUEST['email']);





 
$sql = "UPDATE aice_login SET request_status = '$request_status' WHERE user_email = '$user_email'";


    
    if(mysqli_query($link, $sql)){
     echo '<script>alert (" New Record Inserted Successfully")</script>';
     header("Location:index.php");
	
}



else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 }

//Close connection
mysqli_close($link);
?>