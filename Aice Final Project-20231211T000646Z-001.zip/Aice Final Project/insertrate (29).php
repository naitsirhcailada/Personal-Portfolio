<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3307", "root", "root", "aice");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
if(isset($_POST['heart'])){

   
$product_id = $_POST['product_id'];
// Escape user inputs for security
$product_rate = mysqli_real_escape_string($link, $_POST['heart']);



$sql = " UPDATE aice_product SET product_rate = product_rate+1 WHERE product_id='".$product_id."' ";


}


if(mysqli_query($link, $sql)){
    echo '<script>alert("Product Successfully Checkout")</script>';  
 
     header("Location:aice.php");
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>