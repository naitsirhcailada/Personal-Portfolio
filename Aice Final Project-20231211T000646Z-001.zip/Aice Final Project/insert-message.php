<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3307", "root", "root", "aice");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}



if(isset($_POST['send'])){

   

// Escape user inputs for security
$message = mysqli_real_escape_string($link, $_REQUEST['message']);

$Name = mysqli_real_escape_string($link, $_REQUEST['Name']);
$receiver = mysqli_real_escape_string($link, $_REQUEST['select-user']);
$type = mysqli_real_escape_string($link, $_REQUEST['Type']);
$msg_status = mysqli_real_escape_string($link, $_REQUEST['stat']);
$subject = mysqli_real_escape_string($link, $_REQUEST['subject']);
$msg_time = date ('Y-m-d H:i:s', strtotime("-5 hour"));




$sql = "INSERT INTO aice_msg (message, Name, msg_time,type,msg_status,receiver,subject) VALUES ('$message', '$Name', '$msg_time','$type','$msg_status','$receiver','$subject') ";


}
if(mysqli_query($link, $sql)){
    echo '<script>alert("Product Successfully Checkout")</script>';  
 
     header("Location:profile.php");
	
} 

else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>