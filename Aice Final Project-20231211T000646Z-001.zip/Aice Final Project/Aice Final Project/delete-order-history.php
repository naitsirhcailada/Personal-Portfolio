<?php

include "dbconn.php"; // Using database connection file here

$order_id = $_GET['order_id']; // get id through query string

$del = mysqli_query($link,"delete from aice_order where order_id = '$order_id'"); // delete query

if($del)
{
    mysqli_close($link); // Close connection
    header("location:profile.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>