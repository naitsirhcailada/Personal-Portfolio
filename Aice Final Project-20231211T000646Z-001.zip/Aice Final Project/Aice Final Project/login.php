<?php 
 session_start();
 $message="";

 if(count($_POST)>0) {
   
   $password = $_POST['password'];
  $encrypt = md5($password);
     $con = mysqli_connect('127.0.0.1:3307','root','root','aice') or die('Unable To connect');
     $result = mysqli_query($con,"SELECT * FROM aice_login WHERE user_email='" . $_POST["username"] . "' OR Contact_number = '".$_POST["username"]."' and password = '". $encrypt."'");
     $row  = mysqli_fetch_array($result);
     if(is_array($row)) {
     $_SESSION["user_ID"] = $row['user_ID'];
     $_SESSION["Name"] = $row['Name'];
     $_SESSION['Type'] = $row['Type'];
     
    
     }

 
    
     else {
      echo '<script>alert("Invalid username and password")</script>';
     }
 }

 if(isset($_SESSION["user_ID"]) && ($_SESSION["Type"] =="user")  ) {

 header("Location:aice.php");
 
 }
 else if(isset($_SESSION["user_ID"]) && ($_SESSION["Type"] =="admin")  ) {
  header("location:admin/admin-html/admin.php");
  } 
  else if(isset($_SESSION["user_ID"]) && ($_SESSION["Type"] =="courier")  ) {
    header("location:courier.php");
    }
 



 
?>
<!doctype html>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/login.css" type="text/css" media="screen"/>
    
    <title>Aice Login</title>
  </head>
  <body>


  <div class="message"><?php if($message!="") { echo $message; } ?></div>
  <div class="content">
    <div class="container">
      <div class="row">
       
       
        <div class="col-md-6 col-sm-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <img src="images/8b167af653c2399dd93b952a48740620.jpg"/>
              <h3>LOGIN <p style="font-family: 'Lobster', cursive; color: blueviolet;" >Aice Ice Cream</p></h3>
            
            </div>
            <form method = "post">
              <div class="form-group first">
                <label for="username"><i class="fa fa-user" aria-hidden="true"></i>  Username</label>
                <input type="text" class="form-control" id="username"name = "username" required>

              </div>
              <div class="form-group last mb-4">
                <label for="password"><i class="fa fa-key" aria-hidden="true"></i>   Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
                
              </div>
              
              <div class="d-flex mb-5 align-items-center">
                <label class="control control--checkbox mb-0"><span class="caption">Remember me</span>
                  <input type="checkbox" checked="checked"/>
                  <div class="control__indicator"></div>
                </label>
                <span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span> 
              </div>

              <input type="submit" value="LOGIN" class="btn text-white btn-block btn-info">

             
            </form>
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

  

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>