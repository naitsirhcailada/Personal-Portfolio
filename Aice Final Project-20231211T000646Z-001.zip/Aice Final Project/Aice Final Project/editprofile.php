<?php 

session_start();



  $connection = mysqli_connect("localhost:3307","root","root");
	$db = mysqli_select_db($connection,'aice');
	
	if(isset($_POST['update']))
	{
		$user_ID = $_SESSION['user_ID'];
		$Name = $_POST['name'];
		$username = $_POST['user'];
		$password = $_POST['pass'];
		$Contact_number = $_POST['contact'];
    $Description = $_POST['descrip'];
   
		$query = " update aice_login set Name = '".$Name."', username='".$username."',password='".$password."',Contact_number='".$Contact_number."',Description='".$Description."'  where user_ID='".$user_ID."'";
		$query_run = mysqli_query($connection,$query);
		
		if($query_run)
		{
            header("location:profile.php");
			echo '<script type = "text/javascript">alert("Data Updated")</script>';
           
		}
		else 
		{
			echo '<script type = "text/javascript">alert("Data Not Updated")</script>';
		}
	}

?>

<!doctype html>
<html lang="en">
<head>  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link href="css/editprofile.css" rel="stylesheet">

<!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet"></head>
<title>Aice Nasugbu Branch - Edit Profile</title>
<body>
<!--Nav Bar-->
    <nav class="navbar navbar-expand-lg ">
        <a class="navbar-brand" href="#">Aice</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="aice.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="menu.php">Menu</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link " href="cart.php">Cart</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="map.php">Map</a>
              </li>
              <li class="nav-item">
	  <form class="form-inline my-2 my-lg-0">
    	<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-info my-2 my-sm-0" type="submit">Search</button>
	  </form>
</li>
          <li class="nav-item">
            <a class="nav-link-login " href="logout.php">Log Out</a>
          </li>
        </ul>
      </nav>


      <div class= "card">
         
        <div class="card-header"><strong>Update my Profile</strong>
            <h6>Manage your account</h6>
            <a href = "profile.php"><button type = "button" class="btn btn-primary" name = "back" id = "back">Back</button></a>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 border-right">
                   
                   
                </div>
              
          <form class="inline-block" action="editprofile.php" method="POST">
            <div class="form-group">
            <div class="row mt-2">
                    <div class="col-md-6"><input type="text" class="form-control" placeholder="<?php echo $_SESSION["user_ID"]; ?>" id="user_ID" name ="user_ID" disabled></div>
                   <label for="user_ID" >User ID:</label>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6"><input type="text" class="form-control"  placeholder = "username"id="user" name = "user" required></div>
                   <label for="user" >Username:</label>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6"><input type="text" class="form-control"  id="name" name ="name" placeholder = "<?php echo $_SESSION["Name"]; ?>" required></div>
                    <label for="name" >Name:</label>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6"><input type="text" class="form-control"  placeholder = "contact" id="contact" name ="contact" required></div>
                    <label for="contact" >Contact:</label>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6"><input type="password" class="form-control"  placeholder = "password"id="pass" name = "pass" required></div>
                  <label for="pass" >Password:</label>
                </div>
               
                <div class="row mt-2">
                  <div class="col-md-6"><input type="text" class="form-control"  placeholder = "description"id="descrip" name = "descrip" required></div>
                <label for="descrip" >Description:</label>
              </div>
           

          </form>
        </div> 
    </div>
    <div class="card-footer">
            <button type = "submit" class="btn btn-success" name = "update" id = "update">Update</button>
        </div>
       
      </div>
     
</body>
</html>
<script>var Days = [31,28,31,30,31,30,31,31,30,31,30,31];// index => month [0-11]
  $(document).ready(function(){
      var option = '<option value="day">day</option>';
      var selectedDay="day";
      for (var i=1;i <= Days[0];i++){ //add option days
          option += '<option value="'+ i + '">' + i + '</option>';
      }
      $('#day').append(option);
      $('#day').val(selectedDay);
  
      var option = '<option value="month">month</option>';
      var selectedMon ="month";
      for (var i=1;i <= 12;i++){
          option += '<option value="'+ i + '">' + i + '</option>';
      }
      $('#month').append(option);
      $('#month').val(selectedMon);
  
      var option = '<option value="month">month</option>';
      var selectedMon ="month";
      for (var i=1;i <= 12;i++){
          option += '<option value="'+ i + '">' + i + '</option>';
      }
      $('#month2').append(option);
      $('#month2').val(selectedMon);
    
      var d = new Date();
      var option = '<option value="year">year</option>';
      selectedYear ="year";
      for (var i=1930;i <= d.getFullYear();i++){// years start i
          option += '<option value="'+ i + '">' + i + '</option>';
      }
      $('#year').append(option);
      $('#year').val(selectedYear);
  });
  function isLeapYear(year) {
      year = parseInt(year);
      if (year % 4 != 0) {
          return false;
      } else if (year % 400 == 0) {
          return true;
      } else if (year % 100 == 0) {
          return false;
      } else {
          return true;
      }
  }
  
  function change_year(select)
  {
      if( isLeapYear( $(select).val() ) )
      {
          Days[1] = 29;
          
      }
      else {
          Days[1] = 28;
      }
      if( $("#month").val() == 2)
          {
               var day = $('#day');
               var val = $(day).val();
               $(day).empty();
               var option = '<option value="day">day</option>';
               for (var i=1;i <= Days[1];i++){ //add option days
                   option += '<option value="'+ i + '">' + i + '</option>';
               }
               $(day).append(option);
               if( val > Days[ month ] )
               {
                    val = 1;
               }
               $(day).val(val);
           }
    }
  
  function change_month(select) {
      var day = $('#day');
      var val = $(day).val();
      $(day).empty();
      var option = '<option value="day">day</option>';
      var month = parseInt( $(select).val() ) - 1;
      for (var i=1;i <= Days[ month ];i++){ //add option days
          option += '<option value="'+ i + '">' + i + '</option>';
      }
      $(day).append(option);
      if( val > Days[ month ] )
      {
          val = 1;
      }
      $(day).val(val);
  }</script>