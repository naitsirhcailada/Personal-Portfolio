<?php

include "dbconn.php"; // Using database connection file here

$cart_id = $_GET['submit']; // get id through query string

$del = mysqli_query($link,"delete from cart "); // delete query

if($del)
{
    mysqli_close($link); // Close connection
    header("location:cart.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>