<head><link rel="stylesheet" href="css/footer.css" type="text/css" media="screen"/>

</head>
<footer class="footer-distributed" id="footer">

			<div class="footer-right">

				<a href="#"><i class="fab fa-facebook"></i></a>
				<a href="#"><i class="fab fa-twitter"></i></a>
				

			</div>

			<div class="footer-left">

				<p class="footer-links">
					<a class="link-1" href="aice.php">Home</a>

			

					<a href="map.php">Map</a>

					

					<a href="aboutus.php">About us</a>
				</p>

				<p>Aice Ice Cream &copy; 2021</p>
			</div>

		</footer>
