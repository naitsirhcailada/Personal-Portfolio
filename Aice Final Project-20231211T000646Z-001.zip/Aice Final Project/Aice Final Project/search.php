<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['search'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `aice_product` WHERE CONCAT(`product_ID`, `product_name`, `product_image`,`price_piece` ,`price_box`) LIKE '%".$valueToSearch."%'";
    $result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `aice_product`";
    $result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost:3307", "root", "root", "aice");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>