<?php
//include connection file
include_once("connectionpdf.php");
include_once('fpdf184/fpdf.php');
 session_start();

class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('images/aice logo.png',10,-1,50);
    $this->SetFont('Arial','B',13);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(80,10,'RECEIPT ',1,0,'C');
    // Line break
    $this->Ln(20);
}
 
// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
 
$db = new dbObj();
$connString =  $db->getConnstring();
$display_heading = array('order_id'=>'Order ID', 'product_name'=> 'Product', 'quantity'=> 'Quantity','price'=> 'Price','total'=> 'Total Amount','Name'=> 'Name','Status'=> 'Status','courier'=> 'Courier','order_time'=> 'order time','Address'=> 'address','Contact_number'=> 'Contact','order_image'=> 'order_image','date_delivered'=> 'date_delivered','notif'=> 'notif','delivery_time'=> 'delivery_time');
 
$result = mysqli_query($connString, "SELECT order_id, product_name, quantity, price,total,Name,Status,courier,order_time,Address FROM aice_order WHERE Name = '".$_SESSION['Name']."'") or die("database error:". mysqli_error($connString));
$header = mysqli_query($connString, "SHOW columns FROM aice_order ");
 
$pdf = new PDF();
//header
$pdf->AddPage();
//foter page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',8);
foreach($header as $heading) {
$pdf->Cell(20,6,$display_heading[$heading['Field']],1);
}
foreach($result as $row) {
$pdf->Ln();

foreach($row as $col)
$pdf->Cell(20,20,$col,1);

}
$title = 'Order Receipt';
$pdf->SetTitle($title);
$pdf->Output();
?>