<?php
session_start();
?>
<?php 
 if(!isset($_SESSION['user_ID'])){
  header("location:logout.php");
 }
?>
 <html>
<head><meta name = "viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="css/main.css" type="text/css"  />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <link  rel="stylesheet" href="swiper.min.css"/>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
</head>
<title>Menu - Nasugbu Branch</title>
<style>
 
</style>
<body>
  
 <!--Navbar-->
 <nav class="navbar navbar-expand-lg ">
  <a class="navbar-brand" href="aice.php">Aice</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="aice.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="menu.php">Menu</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="map.php">Map</a>
      </li>

     
      <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search">
      <button class="btn btn-primary my-2 my-sm-0" type="submit">Search</button>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
    <li class="nav-item">
<a class="nav-link" href = "cart.php"><i class="fas fa-shopping-cart" ><span class="badge"><?php echo($row);?></span></i></a>
</li>

<li class="nav-item">
<a class="nav-link"  data-toggle="modal" data-target="#modalContactForm" id = "bell"><i class="fas fa-bell"></i><span class="badge">5</span></a>
</li>
    
    <li class="nav-item dropdown" id="dropdown">
      <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];
                             $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                        ?>
	 
 
  <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2" >'; ?> <?php echo $_SESSION["Name"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="profile.php"><i class ="fa fa-user"></i>&nbsp;Profile</a>
          <a class="dropdown-item" href="cart.php"><i class = "fa fa-shopping-cart"></i>&nbsp;Cart</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php" onclick="return  confirm('Are you sure you want to log out')"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
        </div>
      </li>
   
    </ul>
  </div>
</nav>

<div class="notifications" id="box">
        <h2>Notifications <span>2</span></h2>
        <div class="notifications-item"> <img src="https://i.imgur.com/uIgDDDd.jpg" alt="img">
            <div class="text">
                <h4>Samso aliao</h4>
                <p>Samso Nagaro Like your home work</p>
            </div>
        </div>
        <div class="notifications-item"> <img src="https://img.icons8.com/flat_round/64/000000/vote-badge.png" alt="img">
            <div class="text">
                <h4>John Silvester</h4>
                <p>+20 vista badge earned</p>
            </div>
        </div>
    </div>
<div class = "container-fluid">
	<p class="topsell"><a href="menu.html">All Available Products</p></a>
<!--Card Product Slider-->
<div class="row">
<?php 
      include 'dbconn.php';
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['search'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `aice_product` WHERE CONCAT(`product_id`, `product_name`,`product_image`, `price_piece`,`price_box`) LIKE '%".$valueToSearch."%'";
    $result = mysqli_query($link,$query);
   
}else{

			$query = "select *from aice_product";
		  $result = mysqli_query($link,$query);
}
          while($row = mysqli_fetch_assoc($result)){
 ?>
 
	<div class="col-md-3  col-sm-12">
    
	  <figure class="card card-product">
		<div class="img-wrap"> 
    <?php echo  '<img src = "data:image;base64,' .base64_encode($row['product_image']).'" alt = "No Image"> ' ?>
	   
		</div>
		<figcaption class="info-wrap">
		  <p class="btn-overlay" href="#" name = "product_name" ><strong><?php echo $row['product_name'] ?></strong></p>
		 
		  <div class="action-wrap">
			<a href="exampleModal" data-toggle="modal" data-target="#modalQuickView<?php echo $row['product_id'];?>" class="btn btn-primary btn-sm float-right" ><i class="fa fa-eye "></i> View Product </a>
			<div class="price-wrap h5">
			  <span class="price-new">₱<?php echo $row['price_box'] ?></span>
			
			</div> <!-- price-wrap.// -->
		  </div> <!-- action-wrap -->
		</figcaption>
	  </figure> <!-- card // -->
	</div> <!-- col // -->
  <?php } ?>

  



 <!-- Modal -->
 	<div class="modal fade" id="modalQuickView" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-lg-5">
            <!--Carousel Wrapper-->
            <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails"
              data-ride="carousel">
              <!--Slides-->
              <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                  <img class="d-block w-100"
                    src="images/milk-melon.jpg"
                    alt="First slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block w-100"
                    src="images/choco.jpg"
                    alt="Second slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block w-100"
                    src="images/strawberry.jpg"
                    alt="Third slide">
                </div>
              </div>
              <!--/.Slides-->
              <!--Controls-->
              <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
              <!--/.Controls-->
              <ol class="carousel-indicators">
                <li data-target="#carousel-thumb" data-slide-to="0" class="active">
                  <img src="images/strawberry.jpg" width="60">
                </li>
                <li data-target="#carousel-thumb" data-slide-to="1">
                  <img src="images/choco.jpg" width="60">
                </li>
                <li data-target="#carousel-thumb" data-slide-to="2">
                  <img src="images/milk-melon.jpg" width="60">
                </li>
              </ol>
            </div>
            <!--/.Carousel Wrapper-->
          </div>
          <div class="col-lg-7">
            <h2 class="h2-responsive product-name">
              <strong>Product Name</strong>
            </h2>
            <h4 class="h4-responsive">
              <span class="green-text">
                <strong>$49</strong>
              </span>
              <span class="grey-text">
                <small>
                  <s>$89</s>
                </small>
              </span>
            </h4>

            <!--Accordion wrapper-->
            

            <!-- Add to Cart -->
            <div class="card-body">

				<p>Available Quantity: </p>
              <div class="row">
                <div class="col-md-6">

                  <select class="md-form mdb-select colorful-select dropdown-primary">
                    <option value="" disabled selected>Choose your option</option>
                    <option value="1">Box</option>
                    <option value="2">Piece</option>
                    
                  </select>
                 

                </div>
                <div class="col-md-6">

					<select class="md-form mdb-select colorful-select dropdown-primary">
						<option value="" disabled selected>Choose quantity</option>
						<option value="1">1</option>
						<option value="2">2</option>
						
					  </select>

                </div>
              </div>
              <div class="text-center">

                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button class="btn btn-primary">Add to cart
                  <i class="fas fa-cart-plus ml-2" aria-hidden="true"></i>
                </button>
              </div>
            </div>
            <!-- /.Add to Cart -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  <footer class="footer-distributed">

    <div class="footer-right">

        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        

    </div>

    <div class="footer-left">

        <p class="footer-links">
            <a class="link-1" href="aice.html">Home</a>

            <a href="menu.html">Menu</a>

            <a href="map.html">Map</a>

            <a href="contactus.html">Contact Us</a>

            <a href="#">About</a>
        </p>

        <p>Aice Ice Cream &copy; 2021</p>
    </div>

</footer>
</div><!--container fluid-->
</body>
</html>
<script>
  $(document).ready(function(){




var down = false;

$('#bell').click(function(e){

var color = $(this).text();
if(down){

$('#box').css('height','0px');
$('#box').css('opacity','0');
down = false;
}else{

$('#box').css('height','auto');
$('#box').css('opacity','1');
down = true;

}

});

});
  </script>
