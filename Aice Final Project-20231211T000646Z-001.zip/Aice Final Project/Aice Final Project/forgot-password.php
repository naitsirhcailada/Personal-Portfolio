

<!doctype html>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/login.css" type="text/css" media="screen"/>
    
    <title>Aice Login</title>
  </head>
  <body>


  <div class="content">
    <div class="container">
      <div class="row">
       
       
        <div class="col-md-6 col-sm-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <img src="images/8b167af653c2399dd93b952a48740620.jpg"/><br>
              <h3>FORGOT PASSWORD <p style="font-family: 'Lobster', cursive; color: blueviolet;" >Aice Ice Cream</p></h3>
            
            </div>
          
            <div class="form-group first">
                <label for="email"><i class="fa fa-user" aria-hidden="true"></i>  Email</label>
                <input type="email" class="form-control" id="email"name = "email" required>

              </div>
              <div class="form-group last mb-4">
                <label for="password"><i class="fa fa-key" aria-hidden="true"></i>   Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
                
              </div>
              
             

              <input type="submit" value="Request Reset" class="btn text-white btn-block btn-info">

             
           
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

  

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>