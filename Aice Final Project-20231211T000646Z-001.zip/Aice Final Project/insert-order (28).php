<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost:3307", "root", "root", "aice");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
if(isset($_POST['submit'])){

   

// Escape user inputs for security
$product_name = mysqli_real_escape_string($link, $_REQUEST['product_name']);

$quantity = mysqli_real_escape_string($link, $_REQUEST['quantity']);
$price = mysqli_real_escape_string($link, $_REQUEST['price']);

$total = mysqli_real_escape_string($link, $_REQUEST['total']);
$Name = mysqli_real_escape_string($link, $_REQUEST['fullname']);
$Status = mysqli_real_escape_string($link, $_REQUEST['status']);
$Address = mysqli_real_escape_string($link, $_REQUEST['address']);
$Contact_number = mysqli_real_escape_string($link, $_REQUEST['contact']);
$courier = mysqli_real_escape_string($link, $_REQUEST['courier']);

$order_time = date ('Y-m-d H:i:s', strtotime("+7 hour"));


$cart_id = $_POST['cart'];
$cart_status = $_POST['cart_status'];
$sql = "INSERT INTO aice_order (product_name, quantity, price,total,Name,Status,order_time,Address,Contact_number,courier) VALUES ('$product_name', '$quantity', '$price','$total','$Name','$Status','$order_time','$Address','$Contact_number','$courier') ";

$query = " UPDATE cart SET cart_status = '".$cart_status."'  WHERE cart_id='".$cart_id."'";
}
if(mysqli_query($link, $sql) && mysqli_query($link, $query)){
    echo '<script>alert("Product Successfully Checkout")</script>';  
 
     header("Location:cart.php");
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>