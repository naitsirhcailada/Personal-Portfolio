
<?php
include('dbconn.php');
if(isset($_POST["email"]) && (!empty($_POST["email"]))){
$user_email = $_POST["email"];
$user_email = filter_var($user_email, FILTER_SANITIZE_EMAIL);
$user_email = filter_var($user_email, FILTER_VALIDATE_EMAIL);
if (!$user_email) {
   $error .="<p>Invalid email address please type a valid email address!</p>";
   }else{
   $sel_query = "SELECT * FROM `aice_login` WHERE user_email='".$user_email."'";
   $results = mysqli_query($link,$sel_query);
   $row = mysqli_num_rows($results);
   if ($row==""){
   $error .= "<p>No user is registered with this email address!</p>";
   }
  }
   if($error!=""){
   echo "<div class='error'>".$error."</div>
   <br /><a href='javascript:history.go(-1)'>Go Back</a>";
   }else{
   $expFormat = mktime(
   date("H"), date("i"), date("s"), date("m") ,date("d")+1, date("Y")
   );
   $expDate = date("Y-m-d H:i:s",$expFormat);
   $password_key = md5(2418*2+$user_email);
   $addKey = substr(md5(uniqid(rand(),1)),3,10);
   $password_key = $password_key . $addKey;
// Insert Temp Table
mysqli_query($link,
"INSERT INTO `password_reset` (`email`, `password_key`, `expDate`)
VALUES ('".$user_email."', '".$password_key."', '".$expDate."');");

$output='<p>Dear user,</p>';
$output.='<p>Please click on the following link to reset your password.</p>';
$output.='<p>-------------------------------------------------------------</p>';
$output.='<p><a href="https://www.allphptricks.com/forgot-password/reset-password.php?
password_key='.$password_key.'&email='.$user_email.'&action=reset" target="_blank">
https://www.allphptricks.com/forgot-password/reset-password.php
?password_key='.$password_key.'&email='.$user_email.'&action=reset</a></p>';		
$output.='<p>-------------------------------------------------------------</p>';
$output.='<p>Please be sure to copy the entire link into your browser.
The link will expire after 1 day for security reason.</p>';
$output.='<p>If you did not request this forgotten password email, no action 
is needed, your password will not be reset. However, you may want to log into 
your account and change your security password as someone may have guessed it.</p>';   	
$output.='<p>Thanks,</p>';
$output.='<p>AllPHPTricks Team</p>';
$body = $output; 
$subject = "Password Recovery - AllPHPTricks.com";

$email_to = $user_email;
$fromserver = "noreply@yourwebsite.com"; 

require("PHPMailer-master/PHPMailer-master/src/Exception.php");
require("PHPMailer-master/PHPMailer-master/src/PHPMailer.php");
require("PHPMailer-master/PHPMailer-master/src/SMTP.php");


$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "mail.yourwebsite.com"; // Enter your host here
$mail->SMTPAuth = true;
$mail->Username = "noreply@yourwebsite.com"; // Enter your email here
$mail->Password = "password"; //Enter your password here
$mail->Port = 25;
$mail->IsHTML(true);
$mail->From = "noreply@yourwebsite.com";
$mail->FromName = "AllPHPTricks";
$mail->Sender = $fromserver; // indicates ReturnPath header
$mail->Subject = $subject;
$mail->Body = $body;
$mail->AddAddress($email_to);
if(!$mail->Send()){
echo "Mailer Error: " . $mail->ErrorInfo;
}else{
echo "<div class='error'>
<p>An email has been sent to you with instructions on how to reset your password.</p>
</div><br /><br /><br />";
	}
   }
}else{
?> 
<!doctype html>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/login.css" type="text/css" media="screen"/>
    
    <title>Aice Login</title>
  </head>
  <body>


  <div class="content">
    <div class="container">
      <div class="row">
       
       
        <div class="col-md-6 col-sm-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <img src="images/8b167af653c2399dd93b952a48740620.jpg"/><br>
              <h3>FORGOT PASSWORD <p style="font-family: 'Lobster', cursive; color: blueviolet;" >Aice Ice Cream</p></h3>
            
            </div>
            <form method="post" action="" name="reset">
            <div class="form-group first">
                <label for="email"><i class="fa fa-user" aria-hidden="true"></i>  Email</label>
                <input type="email" class="form-control" id="email"name = "email" required>

              </div>
      
              <input type="submit" name="submit"value="Request Reset" class="btn text-white btn-block btn-info">
              </form>
             
              <?php } ?>
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

  

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>