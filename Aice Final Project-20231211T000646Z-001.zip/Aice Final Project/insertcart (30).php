<?php   
 session_start();  

include 'dbconn.php';

 if(isset($_POST["add-to-cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "product_id");  
           if(!in_array($_GET["product_id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'product_id'               =>     $_GET["product_id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'quantity'          =>     $_POST["qty"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
           }  
           else if(in_array($_GET["product_id"], $item_array_id))  
           {  

               $item_array = array(  

                    'product_id'               =>     $_GET["product_id"],  
                    'name'               =>     $_POST["fullname"],  
                    'item_name'               =>     $_POST["hidden_name"],  
                    'item_price'          =>     $_POST["hidden_price"],  
                    'quantity'          =>     $_POST["qty"]  
               );  
               
                    $product_name = mysqli_real_escape_string($link, $item_array['item_name']);
                    $price = mysqli_real_escape_string($link, $item_array['item_price']);
                    $quantity = mysqli_real_escape_string($link, $item_array['quantity']);
                    $Fullname = mysqli_real_escape_string($link, $item_array['name']);
                    $sql = "INSERT INTO cart(product_name,price,quantity,Fullname) VALUES('".$product_name."','".$price."','".$quantity."','".$Fullname."')";
                  
                    mysqli_query($link,$sql);
               
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="aice.php"</script>';  
           
          }
      }  
      else  
      {  
           $item_array = array(  
            'product_id'               =>     $_GET["product_id"],  
            'item_name'               =>     $_POST["hidden_name"],  
            'item_price'          =>     $_POST["hidden_price"],  
            'quantity'          =>     $_POST["qty"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  

    
 } 


 
 ?>

 

 