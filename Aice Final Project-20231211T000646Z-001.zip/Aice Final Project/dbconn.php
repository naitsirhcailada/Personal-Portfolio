<?php 
  $servername="localhost:3307";
  $username="root";
  $password="root";
  $dbname="aice";
  

  mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
  $link = mysqli_connect($servername,$username,$password,$dbname);
  mysqli_select_db($link,$dbname)  or die("SQL ERROR: Can't select DB");

  ?>