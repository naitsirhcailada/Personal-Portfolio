<?php
session_start();
?>

<?php 
 if(!isset($_SESSION['user_ID'])){
  header("location:logout.php");
 }
?>
<html>
    <head>
        <meta name = "viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href= "css/map.css">
   
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <link  rel="stylesheet" href="swiper.min.css"/>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
 
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!--Font-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">


  </head>
    <title>Map - Nasugbu Branch</title>
<body>
 <!--Navbar-->

 <nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="aice.php">Aice</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" class ="navbar-txt"href="aice.php">Home <span class="sr-only">(current)</span></a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link " href="map.php" >Map</a>
      </li>

     
      <form class="form-inline my-2 my-lg-0" method = "POST" action = "aice.php">
      <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name ="search">
      <button class="btn btn-primary my-2 my-sm-0" type="submit" name="searchproduct" ><i class="fa fa-search"></i>Search</button>
    </form>
    <?php 
      include 'dbconn.php';
			$query = "select *from aice_product";
		  $result = mysqli_query($link,$query);
          $row = mysqli_fetch_assoc($result)
  ?>
     <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."' && cart_status != 'Ordered'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
<li class="nav-item">
  <a class="nav-link" href = "cart.php"><i class="fas fa-shopping-cart" ><span class="badge"><?php echo ($row);?></span></i></a>
</li>
<?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);
      include 'dbconn.php';
			$query = "select *from aice_order  where Name = '".$_SESSION['Name']."' && notif ='unread'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
          $rows= mysqli_fetch_assoc($result);
 ?>
<li class="nav-item">
<div class="dropdown" id=  "ordernotif">

  <button class="btn btn-outline-secondary dropdown-toggle" type="button" name= "submit" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-bell"><span class = "badge"><?php echo ($row);?></span></i>
  </button>
  
  <form action = "updatenotif.php" method = "POST">
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">


   
      <input type ="hidden" name = "order_id" value = "<?php echo $rows['order_id'];?>"/>
      <input type ="hidden" name = "clearnotif" value = "read"/>
    <button type = "submit" name = "updatenotif" class = "notif" <?php if ($rows['notif'] !== 'unread'){  ?> disabled <?php   } ?>>Clear Notifications<br><?php if($rows['notif'] !== 'unread'){ echo'No New Notifications';}?></button>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);

      include 'dbconn.php';
      
			$query = "select *from aice_order  where Name = '".$_SESSION['Name']."' && notif ='unread'";
		  $result = mysqli_query($link,$query);
        
          while($rows= mysqli_fetch_assoc($result)){


 ?>   
           
           <small>Order No:<strong><?php echo $rows["order_id"]; ?></strong><br>
            is &nbsp;<strong><?php echo $rows["Status"]; ?><br></small></strong>;
         
      

    
  
         <?php } ?>
  </div>
 

</div>

</li>
<?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);
      include 'dbconn.php';
			$query = "select *from aice_msg  where receiver = '".$_SESSION['Name']."' && msg_status ='unread'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
          $rows= mysqli_fetch_assoc($result);
 ?>
<li class="nav-item">
<div class="dropdown" id = "msgnotif" >

  <button class="btn btn-outline-secondary dropdown-toggle" type="button" name= "submit" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="fas fa-comment-alt"><span class = "badge"><?php echo ($row);?></span></i>
  </button>
  
  <form action = "updatemsg.php" method = "POST">
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">


   
      <input type ="hidden" name = "msg_id" value = "<?php echo $rows['msg_id'];?>"/>
      <input type ="hidden" name = "clearnotif" value = "read"/>
    <button type = "submit" name = "updatenotif" class = "notif" <?php if ($rows['msg_status'] !== 'unread'){  ?> disabled <?php   } ?>>Clear Notifications<br><?php if($rows['msg_status'] == 'read'){ echo'No New Notifications';}?></button>
    </form>
    <?php 
        error_reporting(E_ALL ^ E_WARNING); 
        error_reporting(0);

      include 'dbconn.php';
      
			$query = "select *from aice_msg WHERE receiver = '".$_SESSION['Name']."' && msg_status ='unread'";
		  $result = mysqli_query($link,$query);
        
          while($rows= mysqli_fetch_assoc($result)){


 ?>   
           
           <small>From:<strong><?php echo $rows["Name"]; ?></strong><br>
            Subject:<strong><?php echo $rows["subject"]; ?></strong><br>
             Message:<strong><?php echo $rows["message"]; ?><br></small></strong>
         
      

    
  
         <?php } ?>
  </div>
 

</div>

</li>



    <li class="nav-item dropdown" id="dropdown" name = "fullname">
      <?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];
                             $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                        ?>
	 
 
  <?php
  if($_SESSION["Name"]) {
  ?>
 
  <?php
  }else echo "<h1>Please login first .</h1>";
  ?>

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2" >'; ?> <?php echo $_SESSION["Name"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="profile.php"><i class ="fa fa-user"></i>&nbsp; Profile</a>
          <a class="dropdown-item" href="cart.php"><i class = "fa fa-shopping-cart"></i>&nbsp;Cart</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"onclick="return  confirm('Are you sure you want to log out')"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
        </div>
      </li>
   
   
    </ul>

  </div> <!--Collapase navbar-->
</nav>


 
<div class = "container">
  
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d242.00833776745012!2d120.62646852760435!3d13.950661408927951!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bdbd2c7b341907%3A0x50bc101c330b2b29!2sAICE%20Ice%20Cream%20-%20Matabungkay!5e0!3m2!1sen!2sph!4v1634309644041!5m2!1sen!2sph" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>



<footer class="footer-distributed">

    <div class="footer-right">

        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        

    </div>

    <div class="footer-left">

        <p class="footer-links">
            <a class="link-1" href="aice.html">Home</a>

            <a href="menu.html">Menu</a>

            <a href="#">Map</a>

            <a href="contactus.html">Contact Us</a>

            <a href="#">About</a>
        </p>

        <p>Aice Ice Cream &copy; 2021</p>
    </div>

</footer>
</body>
</html>
