<?php
session_start();

?>
<?php 
 if(!isset($_SESSION['user_ID'])){
  header("location:logout.php");
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="userprofile.css" type="text/css" media="screen" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <title>User Profile</title>
</head>
<body>
<nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="aice.php">Aice</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="aice.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="menu.php">Menu</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="map.php">Map</a>
            </li>
      
           
            <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-primary my-2 my-sm-0" type="submit">Search</button>
          </form>
          <?php 
        error_reporting(E_ALL ^ E_WARNING); 
      include 'dbconn.php';
			$query = "select *from cart  where Fullname = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          $row = mysqli_num_rows($result);
 ?>
      <li class="nav-item">
        <a class="nav-link" href="cart.php" ><i class="fas fa-shopping-cart" ><span class="badge"><?php echo ($row);?></span></i></a>
      </li>
      <li class="nav-item">
         <a class="nav-link"  data-toggle="modal" data-target="#modalContactForm"><i class="fas fa-comment"></i></a>
      </li>
      <li class="nav-item">
         <a class="nav-link"  data-toggle="modal" data-target="#modalContactForm"><i class="fas fa-bell"></i><span class="badge">5</span></a>
      </li>
       
          <li class="nav-item dropdown" id="dropdown">
            <?php 
                                  include 'dbconn.php';
                                  $user_ID=$_SESSION['user_ID'];
                                   $query = "SELECT `avatar` FROM `aice_login` WHERE user_ID='".$user_ID."'";
                                  $result = mysqli_query($link,$query);
                                  $row = $result->fetch_assoc();
                              ?>
           
       
        <?php
        if($_SESSION["Name"]) {
        ?>
       
        <?php
        }else echo "<h1>Please login first .</h1>";
        ?>
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic me-2 "  >'; ?><?php echo $_SESSION["Name"]; ?>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="profile.php"><i class ="fa fa-user"></i>&nbsp;Profile</a>
                <a class="dropdown-item" href="cart.php"><i class = "fa fa-shopping-cart"></i>&nbsp;Cart</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php" onclick="return  confirm('Are you sure you want to log out')"><i class="fas fa-sign-out-alt"></i>&nbsp;Log Out</a>
              </div>
            </li>
         
          </ul>
        </div>
</nav>


<div class = "container">
        <div class = "row">
          <div class = "col-xs-12 col-sm-6 col-md-8">

          <?php echo  '<img src = "data:image;base64,' .base64_encode($row['avatar']).'" alt="user" class="profile-pic1 me-2" >'; ?>
          <p class = "name"> <strong><?php echo $_SESSION['Name'];?><div id="circle"></div></strong></p>
        
      </div>
      </div>

      <div class="tab">
  <button class="tablinks" onclick="openCity(event, 'User')">User Information</button>
  <button class="tablinks" onclick="openCity(event, 'Order')">Order</button>
  <button class="tablinks" onclick="openCity(event, 'Tokyo')">Edit Profile</button>
</div>

<div id="User" class="tabcontent">
<?php 
                            include 'dbconn.php';
                            $user_ID=$_SESSION['user_ID'];

                            
                            $query = "SELECT *FROM `aice_login` WHERE user_ID='".$user_ID."'";
                            $result = mysqli_query($link,$query);
                            $row = $result->fetch_assoc();
                            ?>

  
<div class="row">
    <div class="card">
      <div class = "card-header"> <h5 class="card-title">User Details<span> <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#multiCollapseExample2" aria-expanded="false" aria-controls="multiCollapseExample2">Update Profile</button></span></h5> </div>
      <div class="card-body">
       
        
        <p class="card-text">Username: <strong>&nbsp; <?php echo $row["username"]; ?></strong></p>
        <p class="card-text">Full Name: <strong>&nbsp; <?php echo $row["Name"]; ?></strong></p>
        <p class="card-text">Contact Number: <strong>&nbsp; <?php echo $row["Contact_number"]; ?></strong></p>
        <p class="card-text">Address: <strong>&nbsp; <?php echo $row["Address"]; ?></strong></p>
        <p class="card-text">Registered Reseller Since: <strong>&nbsp; <?php echo $row["account_created"]; ?></strong></p>
      
      </div>
      </div>
    </div>
 
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample2">
    <div class= "card">
         <div class="card-header"><strong>Update my Profile</strong>
             <h6>Manage your account</h6>
          
         </div>
         <div class="card-body">
             <div class="row">
                 <div class="col-md-4 border-right">
                    
                    
                 </div>
               
           <form class="inline-block" action="editprofile.php" method="POST">
             <div class="form-group">
             <div class="row mt-2">
                     <div class="col-md-6"><input type="text" class="form-control" placeholder="<?php echo $_SESSION["user_ID"]; ?>" id="user_ID" name ="user_ID" disabled></div>
                    <label for="user_ID" >User ID:</label>
                 </div>
                 <div class="row mt-2">
                     <div class="col-md-6"><input type="text" class="form-control"  placeholder = "username"id="user" name = "user" required></div>
                    <label for="user" >Username:</label>
                 </div>
                 <div class="row mt-2">
                     <div class="col-md-6"><input type="text" class="form-control"  id="name" name ="name" placeholder = "<?php echo $_SESSION["Name"]; ?>" required></div>
                     <label for="name" >Name:</label>
                 </div>
                 <div class="row mt-2">
                     <div class="col-md-6"><input type="text" class="form-control"  placeholder = "contact" id="contact" name ="contact" required></div>
                     <label for="contact" >Contact:</label>
                 </div>
                 <div class="row mt-2">
                     <div class="col-md-6"><input type="password" class="form-control"  placeholder = "password"id="pass" name = "pass" required></div>
                   <label for="pass" >Password:</label>
                 </div>
                
                 <div class="row mt-2">
                   <div class="col-md-6"><input type="text" class="form-control"  placeholder = "description"id="descrip" name = "descrip" required></div>
                 <label for="descrip" >Description:</label>
               </div>
            
 
           </form>
         </div> 
     </div>
     <div class="card-footer">
             <button type = "submit" class="btn btn-info" name = "update" id = "update">Update</button>
         </div>
        
       </div>
    </div>
  </div>
</div>
</div>

<!--Order -->
<div id="Order" class="tabcontent">
<div class="d-flex flex-column justify-content-center align-items-center" id="order-heading">
    <div class="text-uppercase">
        <p>Order detail</p>
    </div>
    <div class="h4"></div>
    <div class="pt-1">
        <p>Order #12615 is currently<b class="text-dark"> processing</b></p>
    </div>
    <div class="btn close text-white"> &times; </div>
</div>
<div class="wrapper bg-white">
    <div class="table-responsive">
        <table class="table table-borderless">
            <thead>
                <tr class="text-uppercase text-muted">
                    <th scope="col">product</th>
                   
                </tr>
            </thead>
            <tbody>
                <tr>
                  
                   
                </tr>
            </tbody>
        </table>
    </div>
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_order where Name = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
    <div class="d-flex justify-content-start align-items-center list py-1">
        <div><b><?php echo $row['quantity'];?></b></div>
        <div class="mx-3"> <img src="https://images.pexels.com/photos/206959/pexels-photo-206959.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="apple" class="rounded-circle" width="30" height="30"> </div>
        <div class="order-item"><?php echo $row['product_name'];?></div>
    </div>
   <?php } ?>
    <div class="pt-2 border-bottom mb-3"></div>
    <div class="d-flex justify-content-start align-items-center pl-3">
        <div class="text-muted">Payment Method</div>
        <div class="ml-auto">  <label>Cash On Delivery</label> </div>
    </div>
    <div class="d-flex justify-content-start align-items-center py-1 pl-3">
        <div class="text-muted">Shipping</div>
        <div class="ml-auto"> <label>Free</label> </div>
    </div>
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_order where Name = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
    <div class="d-flex justify-content-start align-items-center pl-3 py-3 mb-4 border-bottom">
        <div class="text-muted"> Today's Total </div>
        <div class="ml-auto h5">₱<?php echo $row['total'];?></div>
    </div>
    <?php } ?>
    <div class="row border rounded p-1 my-3">
        <div class="col-md-6 py-3">
            <div class="d-flex flex-column align-items start"> <b> Address</b>
                <p class="text-justify pt-2">James Thompson, 356 Jonathon Apt.220,</p>
                <p class="text-justify">New York</p>
            </div>
        </div>
        <?php 
      include 'dbconn.php';

			$query = "select *from aice_login where Name = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
        <div class="col-md-6 py-3">
            <div class="d-flex flex-column align-items start"> <b><?php echo $row['Address'];?></b>
               
            </div>
        </div>
    </div>
    <?php } ?>
    <?php 
      include 'dbconn.php';

			$query = "select *from aice_order where Name = '".$_SESSION['Name']."'";
		  $result = mysqli_query($link,$query);
          while($row = mysqli_fetch_assoc($result)){
 ?>
    <div class="pl-3 font-weight-bold"></div>
    <div class="d-sm-flex justify-content-between rounded my-3 subscriptions">
        <div> <b>#9632</b> </div>
        <div>May 22, 2017</div>
        <div>Status: <?php echo $row['Status'];?></div>
        <div>Courier: <?php echo $row['courier'];?></div>
        <div>  <button class="text-white btn btn-info">Order Received</button> </div>
    </div>
 <?php } ?>
</div>
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>


   <!--modal receipt-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Order Status</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>


    
      <div class="modal-body">
  <!--Order Card-->
     
                            
      

        
</div><!--container-->  
</body>
</html>
<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
